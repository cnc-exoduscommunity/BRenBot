BIATCH Plugin
Version 1.00
Daniel Paul (danpaul88)
danpaul88@yahoo.co.uk


This plugin provides an interface to use the console commands in BIATCH, and handles BIATCH
logfile output. For more detailed information about what the commands do refer to the offical
BIATCH documentation at www.black-intel.net

BIATCH is a BlackIntel product.

If you want to ask any questions, request new features or report bugs please post on the Renegade
Public forums (www.renegadeforums.com) in the Technical Support -> Other area, or email me.


###############
Installation
###############

Extract the biatch.pm and biatch.xml files to the BRenBot/plugins folder.


###############
Changelog
###############

1.0
 - First Release


###############
Commands
###############

!trust <name>
Trusts the specified player

!untrust <name>
Untrusts the specified player