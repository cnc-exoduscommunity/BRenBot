IPbot Plugin
Version 1.122
Daniel Paul (danpaul88)
danpaul88@yahoo.co.uk


The IPbot sends the ip's of all players on your server to the main IPBot server, and
allows you to do searches on the IPbot server database. Useful for banning users on
all of their nicknames / ips.

If you want to ask any questions, request new features or report bugs please post on
the Renegade Public forums (www.renegadeforums.com) in the Technical Support -> Other
area, or email me.


###############
Installation
###############

Extract the plugins folder to your BRenBot folder.


###############
Changelog
###############

1.122
 - Fixed bug where queries would queue up indefinatly when the server is offline and then
     all be sent at once, resulting in a large network traffic surge.
 - Added !commonNickSearch command, which searches for any nicknames that have been used
     on the ip address(es) used by a particular player.

1.121
 - Fixed a bug where searches with no results would not show any message in IRC

1.12
 - Modified scan_players to correct a bug where player names were not being sent, and
     adjusted it to run every 5 minutes instead of every 2.
 - Results of searches will now be sent to the person making the request via a NOTICE
     instead of displayed in normal IRC chat

1.11
 - Removed some remaining references to the old IRC connection
 - Modified behaviour of scan_players to report entire playerlist at once instead of
     processing in groups of three, which was only in place due to IRC message queuing

1.1
 - Dropped support for versions of BRenBot older than 1.51
 - Updated to use new ipbot instruction set
 - Connection to the IPBot master server is now done through TCP instead of using IRC

1.02
 - Support for updating through brLoader
 
1.01
 - Updated to be backwards compatible with 1.50

1.0
 - First Release
 - Updated to be compatible with BRenBot 1.51

0.80
 - First Beta Release


###############
Commands
###############

!nicksearch <nick>
Searches the ipbot database for any nicknames matching or containing your search string.
If found it will show up to 10 results, along with their known ip addresses.

!ipsearch <ip>
Searches the ipbot databases for any matches on the specified ip address. If found it
will show up to 10 results, along with the nicknames that have been seen using them.

!ipbot_stats
Shows statistics about the ipbot.