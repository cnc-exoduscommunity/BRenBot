#
# IPBot plugin for BRenBot 1.51 by Daniel Paul
# Reports player IP's to the IPBot server, and allows IRC users to query the server
#
# Version 1.02
#
package ipbot;

use POE;
use plugin;

sub CHANNEL () { plugin::get_irc_channel()  };

# define additional events in the POE session

our %additional_events =
(
	# !command functions
	"ipsearch" => "ipsearch",
	"nicksearch" => "nicksearch",
	"ipbot_stats" => "ipbot_stats",
	
	# Misc
	"scanPlayers" => "scanPlayers",
	"reportPlayerData" => "reportPlayerData"
);

# BRenBot automatically sets the plugin name
our $plugin_name;

# BRenBot automatically imports the plugin's config (from the xml file) into %config
our %config;

my $pluginVersion = 1.02;


# Global plugin variables
my $serverOnline		= 1;
my $recievedStatusReply	= 0;		# Used when requesting status to see if we had a reply
my $lastScannedID		= 0;

########### Functions for !commands

# Request an ip search in the ipbot db
sub ipsearch
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	if ( $serverOnline == 0 )
	{
		$kernel->post( IRC => privmsg => CHANNEL, "The IPBot server is currently offline..." );
		return;
	}
	
	if ( $args{arg1} =~ m/^\d+(\.\d*)?(\.\d*)?(\.\d*)?$/i )
	{
		sendToServer ( "822 $args{arg1}", $kernel );
	}
	elsif ( $args{arg1} )
	{
		$kernel->post( IRC => privmsg => CHANNEL, "$args{arg1} is not a valid IP address" );
	}
	else
	{
		my $syntaxvalue = $args{settings}->{syntax}->{value};
		$kernel->post( IRC => privmsg => CHANNEL, "Usage: $syntaxvalue" );
	}
}


# Request a nickname search in the ipbot db
sub nicksearch
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	if ( $serverOnline == 0 )
	{
		$kernel->post( IRC => privmsg => CHANNEL, "The IPBot server is currently offline..." );
		return;
	}
	
	if ( $args{arg} =~ m/\!\S+\s(.+)/ )
	{
		sendToServer ( "823 $1", $kernel );
	}
	else
	{
		my $syntaxvalue = $args{settings}->{syntax}->{value};
		$kernel->post( IRC => privmsg => CHANNEL, "Usage: $syntaxvalue" );
	}
}


# Request stats from the ipbot
sub ipbot_stats
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	if ( $serverOnline == 0 )
	{
		$kernel->post( IRC => privmsg => CHANNEL, "The IPBot server is currently offline..." );
		return;
	}
	
	sendToServer ( "820", $kernel );
}


########### Event handlers

sub start
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	# Set our current version in the globals table
	plugin::set_global ( "version_plugin_ipbot", $pluginVersion );
	
	# Schedule a scan of the playerlist, so we can report the players which are currently
	# online. Need to give BRenBot time to get the playerlist sorted out
	my $next_time = int( time() ) + 5;
	$kernel->alarm( scanPlayers => $next_time );
	
	
	# Start the session which will constantly track the server's status
	POE::Session->create
	( inline_states =>
		{
			_start => sub
			{
				# Send initial request in 10 seconds
				$_[HEAP]->{next_alarm_time} = int( time() ) + 10;
				$_[KERNEL]->alarm( requestStatus => $_[HEAP]->{next_alarm_time} );
			},
			checkReplyStatus => sub
			{
				if ( $recievedStatusReply == 1 )
				{
					if ( $serverOnline == 0 )
					{
						$_[KERNEL]->post( IRC => privmsg => CHANNEL, "The IPBot server is now online." );
						$serverOnline = 1;
					}
					
					# Check again in 5 minutes
					$_[HEAP]->{next_alarm_time} = int( time() ) + 300;
				}
				else
				{
					if ( $serverOnline == 1 )
					{
						$_[KERNEL]->post( IRC => privmsg => CHANNEL, "The IPBot server has gone offline." );
						$serverOnline = 0;
					}
					
					# Check again in 1 minute
					$_[HEAP]->{next_alarm_time} = int( time() ) + 60;
				}
				
				$_[KERNEL]->alarm( requestStatus => $_[HEAP]->{next_alarm_time} );
			},
			requestStatus => sub
			{
				$recievedStatusReply = 0;
				
				# Request the status of the server, if it does not reply then it is not online
				sendToServer ( "829", $_[KERNEL] );
				
				# Give the server 5 seconds to respond
				$_[HEAP]->{next_alarm_time} = int( time() ) + 5;
				$_[KERNEL]->alarm( checkReplyStatus => $_[HEAP]->{next_alarm_time} );
			}
		}
	);
}


sub stop
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	
	# Comamnds to run when BRenBot quits
}


sub command
{
	# Triggered on !commands controlled by the plugin
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	# Any commands from IRC or ingame come here
	# From here we should trigger the appropriate subroutine
	if ( $args{command} eq "ipsearch" )
	{
		$kernel->yield( "ipsearch" => \%args );
	}
	elsif ( $args{command} eq "nicksearch" )
	{
		$kernel->yield( "nicksearch" => \%args );
	}
	elsif ( $args{command} eq "ipbot_stats" )
	{
		$kernel->yield( "ipbot_stats" => \%args );
	}
}


sub playerjoin
{
	# Triggered when a player joins the game
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	# Schedule them to be reported to the server in 3 seconds
	# Gives BRenBot time to get their IP
	my $next_time = int( time() ) + 3;
	$kernel->alarm( reportPlayerData => $next_time => $args{nick} );
}


sub text
{
	# Triggered on any text from irc or ingame
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	# Discard messages which are not irc pm's
	if ( $args{'messagetype'} ne "irc_privmsg" )
	{
		return;
	}
	
	
	# Results for stats requests
	if ( $args{'message'} =~ m/^830 (\d+) (\d+) (\d+)/i )
	{
		$kernel->post( IRC => privmsg => CHANNEL, "There are currently $1 records in the ipbot's database, consisting of $2 unique player nicknames and $3 unique ip addresses." );
	}
	
	
	# Response to status requests
	if ( $args{'message'} =~ m/^839$/i )
	{
		$recievedStatusReply = 1;
	}
	
	
	# Results for ip seaches
	if ( $args{'message'} =~ m/^831 (\d+) (\d+)/i )
	{
		if ( $1 ne $2 )
		{
			$kernel->post( IRC => privmsg => CHANNEL, "Found $2 results for your search, displaying first $1 results." );
		}
		elsif ( $1 eq '0' )
		{
			$kernel->post( IRC => privmsg => CHANNEL, "Unable to find any records matching your search term." );
		}
		else
		{
			$kernel->post( IRC => privmsg => CHANNEL, "Found $2 results for your search, displaying all results." );
		}
	}
	
	
	elsif ( $args{'message'} =~ m/^832 (\d+\.\d+\.\d+\.\d+) (.+)/i )
	{
		my $message = "7 ".$1.": ( ";
		
		$2 =~ m/^([^:]+):(\d+)(.+)?/i;
		$message .= "$1 (".modules::get_past_date_time ( "DD/MM/YY", $2 ).")";
		
		# Process any extra names's
		my $loopCount = 0;
		while ( length($3) > 0 && $loopCount <= 15 )
		{
			$3 =~ m/^, ([^:]+):(\d+)(.+)?/i;
			$message .= ", $1 (".modules::get_past_date_time ( "DD/MM/YY", $2 ).")";
			$loopCount++;
		}
		
		$message .= " )";
		
		$kernel->post( IRC => privmsg => CHANNEL, $message );
	}
	
	
	# Results for nick searches
	elsif ( $args{'message'} =~ m/^833 (\d+) (\d+)/i )
	{
		if ( $1 ne $2 )
		{
			$kernel->post( IRC => privmsg => CHANNEL, "Found $2 results for your search, displaying first $1 results." );
		}
		elsif ( $1 eq '0' )
		{
			$kernel->post( IRC => privmsg => CHANNEL, "Unable to find any records matching your search term." );
		}
		else
		{
			$kernel->post( IRC => privmsg => CHANNEL, "Found $2 results for your search, displaying all results." );
		}
	}
	
	
	elsif ( $args{'message'} =~ m/^834 ([^.]+) (\d+\.\d+\.\d+\.\d+.+)/i )
	{
		my $message = "7 ".$1.": ( ";
		
		$2 =~ m/^(\d+\.\d+\.\d+\.\d+):(\d+)(.+)?/i;
		$message .= "$1 (".modules::get_past_date_time ( "DD/MM/YY", $2 ).")";
		
		# Process any extra ip's
		while ( length($3) > 0 )
		{
			$3 =~ m/^, (\d+\.\d+\.\d+\.\d+):(\d+)(.+)?/i;
			$message .= ", $1 (".modules::get_past_date_time ( "DD/MM/YY", $2 ).")";
		}
		
		$message .= " )";
		
		$kernel->post( IRC => privmsg => CHANNEL, $message );
	}
}


########### Other Functions

# Triggered by the timer on playerjoin event, gets the IP of the player ( if they
# are still ingame ) and reports it to the server
sub reportPlayerData
{
	my ( $session, $heap, $player ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	
	# Get the info for the player
	if ( $main::version >= 1.51 )
	{
		my ( $result, %player ) = plugin::getPlayerData( $player );
		if ( $result == 1 && $serverOnline )
		{
			# Report them to the ipbot server
			sendToServer ( "821 " . $player{'name'} . "@" . $player{'ip'}, $kernel );
		}
	}
	else
	{
		my ( $result, $error, $player ) = modules::PlayerInGame( $player );
		if ( $result == 1 && $serverOnline )
		{
			# Report them to the ipbot server
			sendToServer ( "821 " . $player->{'name'} . "@" . $player->{'ip'}, $kernel );
		}
	}
}

# Scan's and reports all players in game, used when the bot has just loaded so nobody
# gets missed out. Also starts regular scans for players. Scans players in groups of
# three to prevent excessive IRC usage.
sub scanPlayers
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	if ( $serverOnline == 1 )
	{
		my $playersProcessed = 0;
		if ( main::version >= 1.51 )
		{
			my %playerList = plugin::get_playerlist();
			while ( my ( $id, $player ) = each ( %playerlist ) )
			{
				next if ( $id <= $lastScannedID );	# Skip to where we left off
				if ( $playersProcessed == 3 ) { last; }
				
				# Report them to the ipbot server
				if ( $player->{ip} )
				{
					$lastScannedID = $id;
					sendToServer ( "821 " . $player->{name} . "@" . $player->{ip}, $kernel );
					$playersProcessed++;
				}
			}
			if ( $playersProcessed < 3 ) { $lastScannedID = 0; }
		}
		else
		{
			my @playerList = plugin::get_playerlist();
			foreach $player ( @playerList )
			{
				next if ( $player->{id} <= $lastScannedID );	# Skip to where we left off
				if ( $playersProcessed == 3 ) { last; }
				
				# Report them to the ipbot server
				if ( $player->{ip} )
				{
					$lastScannedID = $player->{id};
					sendToServer ( "821 " . $player->{name} . "@" . $player->{ip}, $kernel );
					$playersProcessed++;
				}
			}
			if ( $playersProcessed < 3 ) { $lastScannedID = 0; }
		}
	}
	
	# Schedule another scan in 10 minutes
	my $next_time = int( time() ) + 1200;
	$kernel->alarm( scanPlayers => $next_time );
}


# Sends data to the ipbot server ( nickname IPBot on the IRC Server )
sub sendToServer
{
	my $sendLine = shift;
	my $kernel = shift;
	
	$kernel->post( IRC => privmsg => IPBot, $sendLine );
}


# Return true or the bot will not work properly...
1;