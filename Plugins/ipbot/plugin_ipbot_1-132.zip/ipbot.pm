#
# IPDB plugin for BRenBot 1.52 by Daniel Paul
# Reports player IP's to the IPDB server, and allows IRC users to query the server
#
# Version 1.132
#
package ipbot;

use POE;
use IO::Socket;
use plugin;

# Variables
my $socket;
my @messageQueue;			# Queue for outgoing messages

# define additional events in the POE session

our %additional_events = ( "ipsearch" => "ipsearch",	"nicksearch" => "nicksearch",
"commonnicksearch" => "commonnicksearch",	"ipbot_stats" => "ipbot_stats",
"scanPlayers" => "scanPlayers",		"reportPlayerData" => "reportPlayerData",
"ping" => "ping" );

# BRenBot automatically sets the plugin name and imports config
our $plugin_name;
our %config;

my $pluginVersion = 1.132;


# Global plugin variables
my $serverOnline		= 1;

########### Functions for !commands

# Request an ip search in the ipbot db
sub ipsearch
{
	my ( $kernel, $session, $heap, $args ) = @_[ KERNEL, SESSION, HEAP, ARG0 ];
	my %args = %{$args};
	
	if ( $serverOnline == 0 )
	{
		plugin::ircmsg ( "The IPDB server is currently offline...", $args{'ircChannelCode'} );
		return;
	}
	
	if ( $args{arg1} =~ m/^\d+(\.\d*)?(\.\d*)?(\.\d*)?$/i )
	{
		my $nickname = $args{'nick'};
		$nickname =~ s/\@IRC//gi;
		my $requestID = getRequestId ( $nickname );
		sendToServer ( "703 $requestID:$args{arg1}", $kernel );
	}
	elsif ( $args{arg1} )
	{
		plugin::ircmsg ( "$args{arg1} is not a valid IP address", $args{'ircChannelCode'} );
	}
	else
	{
		my $syntaxvalue = $args{settings}->{syntax}->{value};
		plugin::ircmsg ( "Usage: $syntaxvalue", $args{'ircChannelCode'} );
	}
}


# Request a nickname search in the ipdb db
sub nicksearch
{
	my ( $kernel, $session, $heap, $args ) = @_[ KERNEL, SESSION, HEAP, ARG0 ];
	my %args = %{$args};
	
	if ( $serverOnline == 0 )
	{
		plugin::ircmsg ( "The IPDB server is currently offline...", $args{'ircChannelCode'} );
		return;
	}
	
	if ( $args{arg} =~ m/\!\S+\s(.+)/ )
	{
		my $searchString = $1;
		my $nickname = $args{'nick'};
		$nickname =~ s/\@IRC//gi;
		my $requestID = getRequestId ( $nickname );
		sendToServer ( "704 $requestID:$searchString", $kernel );
	}
	else
	{
		my $syntaxvalue = $args{settings}->{syntax}->{value};
		plugin::ircmsg ( "Usage: $syntaxvalue", $args{'ircChannelCode'} );
	}
}



# Request a common nicknames search in the ipdb db
sub commonnicksearch
{
	my ( $kernel, $session, $heap, $args ) = @_[ KERNEL, SESSION, HEAP, ARG0 ];
	my %args = %{$args};
	
	if ( $serverOnline == 0 )
	{
		plugin::ircmsg ( "The IPDB server is currently offline...", $args{'ircChannelCode'} );
		return;
	}
	
	if ( $args{arg} =~ m/\!\S+\s(.+)/ )
	{
		my $searchString = $1;
		my $nickname = $args{'nick'};
		$nickname =~ s/\@IRC//gi;
		my $requestID = getRequestId ( $nickname );
		sendToServer ( "707 $requestID:$searchString", $kernel );
	}
	else
	{
		my $syntaxvalue = $args{settings}->{syntax}->{value};
		plugin::ircmsg ( "Usage: $syntaxvalue", $args{'ircChannelCode'} );
	}
}


# Request stats from the ipdb
sub ipbot_stats
{
	my ( $kernel, $session, $heap, $args ) = @_[ KERNEL, SESSION, HEAP, ARG0 ];
	my %args = %{$args};
	
	if ( $serverOnline == 0 )
	{
		plugin::ircmsg ( "The IPDB server is currently offline...", $args{'ircChannelCode'} );
		return;
	}
	
	my $nickname = $args{'nick'};
	$nickname =~ s/\@IRC//gi;
	my $requestID = getRequestId ( $nickname );
	sendToServer ( "701 $requestID", $kernel );
}


########### Event handlers

sub start
{
	my ( $kernel ) = @_[ KERNEL ];
	
	# Set our current version in the globals table
	plugin::set_global ( "version_plugin_ipbot", $pluginVersion );
	
	# Schedule a scan of the playerlist, so we can report the players which are currently
	# online. Need to give BRenBot time to get the playerlist sorted out
	$kernel->alarm( scanPlayers => (int( time() ) + 5) );
	
	# Start ping loop
	$kernel->alarm( ping => (int( time() ) + 5) );
	
	
	# Start send / recieve loops ( Only actually do anything when the socket is active )
	# Connect to the ipdb server
	POE::Session->create
	( inline_states =>
		{
			_start => sub
			{
				$serverOnline = 0;
				$_[HEAP]->{'connected'} = 0;
				$_[KERNEL]->alias_set( "ipdbserver" );
				
 				$socket = IO::Socket::INET->new(
 					PeerAddr => 'ipdb.tsulutions.com', 
 					PeerPort => '51988', 
 					Proto => 'tcp' );
 				
 				if ( $socket && $socket->connected() )
 				{
	 				$serverOnline = 1;
 					$_[HEAP]->{'connected'} = 1;
 					print "[IPDB] Connected to IPDB master server.\n";
 					plugin::ircmsg ( "The IPDB server is now online.", "A" );
 					
 					# Send login details
 					sendToServer ( "600 ".$config{'ipdbUser'}.":".$config{'ipdbPass'} );
 					
 					# Register client ID
 					sendToServer ( "601 BRenBot ".$main::version.".".$main::build." (".$pluginVersion.")" );
 					
 					# Start receive wheel and send loop
 					$_[KERNEL]->yield( "startRecieve" );
 					$_[KERNEL]->yield( "sendLoop" );
 				}
 				else
 				{
 					print "[IPDB] Failed to connect to IPDB master server, retrying in 2 minutes.\n";
 					$_[KERNEL]->alarm ( "reconnect" => (time()+120) );
 				}
			},
			reconnect => sub
			{
				$socket = IO::Socket::INET->new(
					PeerAddr => 'IPDB.aohost.co.uk', 
					PeerPort => '51988', 
					Proto => 'tcp' );
				
				if ( $socket && $socket->connected() )
				{
					$serverOnline = 1;
					$_[HEAP]->{'connected'} = 1;
					print "IPDB: Connected to IPDB master server.\n";
					plugin::ircmsg ( "The IPDB server is now online.", "A" );
					
					# Send login details
 					sendToServer ( "600 ".$config{'ipdbUser'}.":".$config{'ipdbPass'} );
 					
 					# Start receive wheel and send loop
					$_[KERNEL]->yield( "startRecieve" );
					$_[KERNEL]->yield( "sendLoop" );
				}
				else
				{
					print "[IPDB] Failed to connect to IPDB master server, retrying in 5 minutes.\n";
					$_[KERNEL]->alarm ( "reconnect" => (time()+300) );
				}
			},
			startRecieve => sub
			{
				$_[HEAP]->{'socket'} = new POE::Wheel::ReadWrite
				(
					Handle     => $socket,
					InputEvent => 'gotline',
					ErrorEvent => 'goterror',
			    );
			},
			sendLoop => sub
			{
				return if ( $_[HEAP]->{'connected'} != 1 );
				
				# Limit message length to 1024 characters
				my $availableChars = 1024;
				my $sendString = "";
				
				# Send at least one message
				if ( $messageQueue[0] )
				{
					my $output = shift @messageQueue;
					$sendString .= $output;
					$availableChars -= length ( $output );
					
					# Keep sending messages until we hit our chars per second limit
					while ( $messageQueue[0] && ( length($messageQueue[0]) < $availableChars ) )
					{
						$output = shift @messageQueue;
						$sendString .= $output;
						$availableChars -= length ( $output );
					}
				}	
				
				# If there's anything to send then send it
				if ( $sendString ) { $socket->send( $sendString ); }
			    
			    # Come back to the send loop in 1 second
			   $_[KERNEL]->delay ( "sendLoop", 1 );
			},
			gotline => sub
			{
				my ( $input ) = @_[ ARG0 ];
				
				#open ( IPBOTDEBUGFILE, '>>ipbotdebug.txt' );
				#print IPBOTDEBUGFILE "RECEIVE: $input\n";
				#close IPBOTDEBUGFILE;
				
				# Do something with input
				parseInput ( $input );
			},
			goterror => sub		# Means we are disconnected
			{
				my ( $error, $errorCode, $errorString ) = @_[ ARG0, ARG1, ARG2 ];
				
				#open ( IPBOTDEBUGFILE, '>>ipbotdebug.txt' );
				#print IPBOTDEBUGFILE "ERROR: $error\n";
				#close IPBOTDEBUGFILE;
				
				$serverOnline = 0;
				$_[HEAP]->{'connected'} = 0;
				
				# Shutdown socket and wheel
				$_[HEAP]->{'socket'}->shutdown_input();
				$_[HEAP]->{'socket'}->shutdown_output();
				delete $_[HEAP]->{'socket'};
				shutdown ( $socket, 2 );
				
				plugin::ircmsg ( "The IPDB server has gone offline.", "A" );
				print "[IPDB] ERROR: Error during $error. Error code $errorCode: $errorString\n";
				print "[IPDB] Disconnect detected, attemping to reconnect in 20 seconds.\n";
				$_[KERNEL]->alarm ( "reconnect" => (time()+20) );
			}
		}
	);
}


sub stop
{}


# Command event - Triggers on any !command which is in this plugins XML file
sub command
{
	my ( $kernel, $args ) = @_[ KERNEL, ARG0 ];
	my %args = %{$args};
	
	# Trigger the event with the same name as the command
	$kernel->yield ( $args{'command'} => \%args );
}


# Playerjoin event
sub playerjoin
{
	my ( $kernel, $args ) = @_[ KERNEL, ARG0 ];
	my %args = %{$args};
	
	# Schedule them to be reported to the server in 3 seconds
	# Gives BRenBot time to get their IP
	$kernel->alarm( reportPlayerData => (int(time()) +3) => $args{'nick'} );
}



####################################
##
# Data Input
#
# Parsing data recieved back from the server
##
####################################

# Parses data recieved from the IPDB server via the socket
sub parseInput
{
	my $input = shift;
	
	if ( $input =~ m/^650/ )
		{ print "[IPDB] Login to IPDB was succesful.\n"; }
	elsif ( $input =~ m/^651/ )
		{ print "[IPDB] Login to IPDB failed, login limit for username has been reached!\n"; }
	elsif ( $input =~ m/^652/ )
		{ print "[IPDB] Login to IPDB failed, username or password was invalid!\n"; }
	elsif ( $input =~ m/^653/ )
		{ process_653($1); }
	
	elsif ( $input =~ m/^721\s(.+)/ )
		{ process_721($1); }
	elsif ( $input =~ m/^723\s(.+)/ )
		{ process_723($1); }
	elsif ( $input =~ m/^724\s(.+)/ )
		{ process_724($1); }
	elsif ( $input =~ m/^727\s(.+)/ )
		{ process_727($1); }
}


# Process 653 input ( Request denied )
# 653 reqID				Request denied: Attempted to use feature that requires login
sub process_653
{
	my $input = shift;
	
	if ( $input =~ m/(\d+)/ )
	{
		my $ircUser = getRequestIdOwner ( $1 );
		if ( $ircUser )
		{
			plugin::ircnotice ( $ircUser, "IPDB REQUEST DENIED. Please ensure you are using a valid username and password to connect to the IPDB." );
		}
	}
}


# Process 721 input ( Stats response )
# 721 reqID:records:names:ips		Stats Response
sub process_721
{
	my $input = shift;
	
	if ( $input =~ m/(\d+)\:(\d+)\:(\d+)\:(\d+)/ )
	{
		my $ircUser = getRequestIdOwner ( $1 );
		if ( $ircUser )
		{
			plugin::ircnotice ( $ircUser, "There are currently $2 records in the IPDB database, consisting of $3 unique nicknames and $4 unique IPs" );
		}
	}
}


# Process 723 input ( IP Search Result )
# 723 reqID:found:sending ip Tstmp:name\tTstmp:name\0ip Tstmp:name\tTstmp:name\0	ip search result
sub process_723
{
	my $input = shift;
	
	if ( $input =~ m/(\d+)\:(\d+)\:(\d+)\s(.+)/ )
	{
		my $ircUser = getRequestIdOwner ( $1 );
		if ( $ircUser )
		{
			plugin::ircnotice ( $ircUser, "Found $3 results for your search, showing first $2..." );
			
			my $results = $4;
			while ( $results =~ m/\s*(\S+)\s([^\]+)((.+))?/ )
			{
				$results = $4;
				# 1 = ip
				# 2 = group of names / timestamps
				my $message = "07$1: ( ";
				
				my $names = $2;
				while ( $names =~ m/\s*(\d+)\:([^\t]+)(\t.+)?/ )
				{
					$names = $3;
					$message .= "$2 (".modules::get_past_date_time ( "DD/MM/YY", $1 )."), ";
				}
				
				# Trim trailing ', '
				$message = substr ( $message, 0, -2 );
				
				$message .= " )";
				
				plugin::ircnotice ( $ircUser, $message );
			}
		}
	}
	elsif ( $input =~ m/(\d+)\:0\:0/ )
	{
		my $ircUser = getRequestIdOwner ( $1 );
		if ( $ircUser )
			{ plugin::ircnotice ( $ircUser, "No results found for your search" ); }
	}
}



# Process 724 input ( Nick Search Result )
# 724 reqID:found:sending name Tstmp:ip\tTstmp:ip\0name Tstmp:ip\tTstmp:ip\0	name search result
sub process_724
{
	my $input = shift;
	
	if ( $input =~ m/(\d+)\:(\d+)\:(\d+)\s(.+)/ )
	{
		my $ircUser = getRequestIdOwner ( $1 );
		if ( $ircUser )
		{
			plugin::ircnotice ( $ircUser, "Found $3 results for your search, showing first $2..." );
		
			my $results = $4;
			while ( $results =~ m/\s*([^\ ]+)\s([^\]+)((.+))?/ )
			{
				$results = $4;
				# 1 = ip
				# 2 = group of names / timestamps
				my $message = "07$1: ( ";
				
				my $ips = $2;
				while ( $ips =~ m/\s*(\d+)\:([^\t]+)(\t.+)?/ )
				{
					$ips = $3;
					$message .= "$2 (".modules::get_past_date_time ( "DD/MM/YY", $1 )."), ";
				}
				
				# Trim trailing ', '
				$message = substr ( $message, 0, -2 );
				
				$message .= " )";
				
				plugin::ircnotice ( $ircUser, $message );
			}
		}
	}
	elsif ( $input =~ m/(\d+)\:0\:0/ )
	{
		my $ircUser = getRequestIdOwner ( $1 );
		if ( $ircUser )
			{ plugin::ircnotice ( $ircUser, "No results found for your search" ); }
	}
}



# Process 727 input ( Common Nick Search Result )
# 727 reqID:found:sending name\vname
sub process_727
{
	my $input = shift;
	
	if ( $input =~ m/(\d+)\:(\d+)\:(\d+)\s(.+)/ )
	{
		my $ircUser = getRequestIdOwner ( $1 );
		if ( $ircUser )
		{
			plugin::ircnotice ( $ircUser, "Found $3 results for your search, showing first $2..." );
		
			my $message;
			my $results = $4;
			
			while ( $results =~ m/\s*([^\ ]+)\(.+)?/ )
			{
				# Check message length, if message has become too long send
				# what we have and start an new blank message
				if ( length($message) + length($1) > 450 )
				{
					# Trim trailing ', '
					$message = substr ( $message, 0, -2 );
					plugin::ircnotice ( $ircUser, $message );
					
					# Start new blank message
					$message = "";
				}
				
				
				# Add result to message and grab remaining results
				$message .= "$1, ";
				$results = $2;	
			}
			
			# Trim trailing ', '
			$message = substr ( $message, 0, -2 );
			plugin::ircnotice ( $ircUser, $message );
		}
	}
	elsif ( $input =~ m/(\d+)\:0\:0/ )
	{
		my $ircUser = getRequestIdOwner ( $1 );
		if ( $ircUser )
			{ plugin::ircnotice ( $ircUser, "No results found for your search" ); }
	}
}




####################################
##
# Other Functions
#
# N/A
##
####################################

# Triggered by the timer on playerjoin event, gets the IP of the player ( if they
# are still ingame ) and reports it to the server
sub reportPlayerData
{
	my ( $kernel, $playername ) = @_[ KERNEL, ARG0 ];
	
	# Get and send the info for the player
	my ( $result, %player ) = plugin::getPlayerData( $playername );
	if ( $result == 1 && $serverOnline == 1 && $player{'ip'} )
	{
		# Report them to the ipdb server - request ID 0 (we dont need a reply)
		sendToServer ( "702 00:" . $player{'ip'} . ":" . $player{'name'} );
	}
}

# Ping the server to prevent the connection from being killed
sub ping
{
	my ( $kernel ) = @_[ KERNEL ];
	
	if ( $serverOnline == 1 )
	{
		sendToServer ( "700 " );
	}
	
	# Schedule another ping in 30 seconds
	$kernel->alarm( ping => (int(time()) + 30) );
}

# Scan's and reports all players in game, used when the bot has just loaded so nobody
# gets missed out. Also starts regular scans for players. Scans players in groups of
# three to prevent excessive network traffic.
sub scanPlayers
{
	my ( $kernel ) = @_[ KERNEL ];
	
	if ( $serverOnline == 1 )
	{
		my %playerlist = plugin::get_playerlist();
		while ( my ( $id, $player ) = each ( %playerlist ) )
		{
			# Report them to the ipdb server
			if ( $player->{'ip'} )
			{
				# Report them to the ipdb server - request ID 0 (we dont need a reply)
				sendToServer ( "702 00:" . $player->{'ip'} . ":" . $player->{'name'} );
			}
		}
	}
	
	# Schedule another scan in 10 minutes (tcp mode)
	$kernel->alarm( scanPlayers => (int(time()) + 600) );
}


# Sends data to the ipdb server
sub sendToServer
{
	my $line = shift;
	push ( @messageQueue, "$line\n" );
}




####################################
##
# Request ID functions
#
# Allocates request ID's and remembers who they
# belong to
##
####################################

# Hash to hold request IDs
my %requestIds;

# Allocate a new request ID
sub getRequestId
{
	my $ircUser = shift;
	
	# Allocate a random request ID
	my $requestId = int(rand(99999));
	
	# If this ID is already allocated try another ID until we find a free one
	while ( $requestIds{$requestId} )
		{ $requestId = int(rand(99999)); }
	
	$requestIds{$requestId} = $ircUser;
	return $requestId;
}

# Get the name of the owner of a request ID
sub getRequestIdOwner
{
	my $requestId = shift;
	
	if ( $requestIds{$requestId} )
	{
		my $ircUser = $requestIds{$requestId};
		delete $requestIds{$requestId};
		return $ircUser;
	}
	
	return undef;
}




# Return true or the bot will not work properly...
1;