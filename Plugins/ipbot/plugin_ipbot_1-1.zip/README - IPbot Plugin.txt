IPbot Plugin
Version 1.1
Daniel Paul (danpaul88)
danpaul88@yahoo.co.uk


The IPbot sends the ip's of all players on your server to the main IPBot server, and
allows you to do searches on the IPbot server database. Useful for banning users on
all of their nicknames / ips.

The IPbot server is currently hosted by TheKOSs2. To check if the server is available
on your IRC network join the #ipbot channel and look for the nickname ipbot. If it is
not there, please contact Gozy with the address and port of your IRC server.

If you want to ask any questions, request new features or report bugs please post on
the Renegade Public forums (www.renegadeforums.com) in the Technical Support -> Other
area, or email me.


###############
Installation
###############

Extract the plugins folder to your BRenBot folder.


###############
Changelog
###############

1.1
 - Dropped support for versions of BRenBot older than 1.51
 - Updated to use new ipbot instruction set
 - Connection to the IPBot master server is now done through TCP instead of using IRC

1.02
 - Support for updating through brLoader
 
1.01
 - Updated to be backwards compatible with 1.50

1.0
 - First Release
 - Updated to be compatible with BRenBot 1.51

0.80
 - First Beta Release


###############
Commands
###############

!nicksearch <nick>
Searches the ipbot database for any nicknames matching or containing your search string.
If found it will show up to 10 results, along with their known ip addresses.

!ipsearch <ip>
Searches the ipbot databases for any matches on the specified ip address. If found it
will show up to 10 results, along with the nicknames that have been seen using them.

!ipbot_stats
Shows statistics about the ipbot.