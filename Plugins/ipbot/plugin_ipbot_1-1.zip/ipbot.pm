#
# IPBot plugin for BRenBot 1.51 by Daniel Paul
# Reports player IP's to the IPBot server, and allows IRC users to query the server
#
# Version 1.1
#
package ipbot;

use POE;
use IO::Socket;
use plugin;

# Variables
my $socket;
my @messageQueue;			# Queue for outgoing messages

# define additional events in the POE session

our %additional_events = ( "ipsearch" => "ipsearch",	"nicksearch" => "nicksearch",	"ipbot_stats" => "ipbot_stats",
		"scanPlayers" => "scanPlayers",		"reportPlayerData" => "reportPlayerData" );

# BRenBot automatically sets the plugin name and imports config
our $plugin_name;
our %config;

my $pluginVersion = 1.1;


# Global plugin variables
my $serverOnline		= 1;
my $recievedStatusReply	= 0;		# Used when requesting status to see if we had a reply

########### Functions for !commands

# Request an ip search in the ipbot db
sub ipsearch
{
	my ( $kernel, $session, $heap, $args ) = @_[ KERNEL, SESSION, HEAP, ARG0 ];
	my %args = %{$args};
	
	if ( $serverOnline == 0 )
	{
		plugin::ircmsg ( "The IPBot server is currently offline...", $args{'ircChannelCode'} );
		return;
	}
	
	if ( $args{arg1} =~ m/^\d+(\.\d*)?(\.\d*)?(\.\d*)?$/i )
	{
		sendToServer ( "703 00:$args{arg1}", $kernel );
	}
	elsif ( $args{arg1} )
	{
		plugin::ircmsg ( "$args{arg1} is not a valid IP address", $args{'ircChannelCode'} );
	}
	else
	{
		my $syntaxvalue = $args{settings}->{syntax}->{value};
		plugin::ircmsg ( "Usage: $syntaxvalue", $args{'ircChannelCode'} );
	}
}


# Request a nickname search in the ipbot db
sub nicksearch
{
	my ( $kernel, $session, $heap, $args ) = @_[ KERNEL, SESSION, HEAP, ARG0 ];
	my %args = %{$args};
	
	if ( $serverOnline == 0 )
	{
		plugin::ircmsg ( "The IPBot server is currently offline...", $args{'ircChannelCode'} );
		return;
	}
	
	if ( $args{arg} =~ m/\!\S+\s(.+)/ )
	{
		sendToServer ( "704 00:$1", $kernel );
	}
	else
	{
		my $syntaxvalue = $args{settings}->{syntax}->{value};
		plugin::ircmsg ( "Usage: $syntaxvalue", $args{'ircChannelCode'} );
	}
}


# Request stats from the ipbot
sub ipbot_stats
{
	my ( $kernel, $session, $heap, $args ) = @_[ KERNEL, SESSION, HEAP, ARG0 ];
	my %args = %{$args};
	
	if ( $serverOnline == 0 )
	{
		plugin::ircmsg ( "The IPBot server is currently offline...", $args{'ircChannelCode'} );
		return;
	}
	
	sendToServer ( "701 00", $kernel );
}


########### Event handlers

sub start
{
	my ( $kernel ) = @_[ KERNEL ];
	
	# Set our current version in the globals table
	plugin::set_global ( "version_plugin_ipbot", $pluginVersion );
	
	# Schedule a scan of the playerlist, so we can report the players which are currently
	# online. Need to give BRenBot time to get the playerlist sorted out
	$kernel->alarm( scanPlayers => (int( time() ) + 5) );
	
	
	# Start send / recieve loops ( Only actually do anything when the socket is active )
	# Connect to the ipbot server
	POE::Session->create
	( inline_states =>
		{
			_start => sub
			{
				$_[HEAP]->{'connected'} = 0;
				$_[KERNEL]->alias_set( "ipbotserver" );
				
 				$socket = IO::Socket::INET->new(
 					PeerAddr => 'IPDB.aohost.co.uk', 
 					PeerPort => '51988', 
 					Proto => 'tcp' );
 				
 				if ( $socket && $socket->connected() )
 				{
 					$_[HEAP]->{'connected'} = 1;
 					print "IPBOT: Connected to ipbot master server.\n";
 					plugin::ircmsg ( "The IPBot server is now online.", "A" );
 					
 					# Start receive wheel and send loop
 					$_[KERNEL]->yield( "startRecieve" );
 					$_[KERNEL]->yield( "sendLoop" );
 				}
 				else
 				{
 					print "IPBOT: Failed to connect to ipbot master server, retrying in 2 minutes.\n";
 					$_[KERNEL]->alarm ( "reconnect" => (time()+120) );
 				}
			},
			reconnect => sub
			{
				$socket = IO::Socket::INET->new(
					PeerAddr => 'IPDB.aohost.co.uk', 
					PeerPort => '51988', 
					Proto => 'tcp' );
				
				if ( $socket && $socket->connected() )
				{
					$_[HEAP]->{'connected'} = 1;
					print "IPBOT: Connected to ipbot master server.\n";
					plugin::ircmsg ( "The IPBot server is now online.", "A" );
					
					# Start receive wheel and send loop
					$_[KERNEL]->yield( "startRecieve" );
					$_[KERNEL]->yield( "sendLoop" );
				}
				else
				{
					print "IPBOT: Failed to connect to ipbot master server, retrying in 15 minutes.\n";
					$_[KERNEL]->alarm ( "reconnect" => (time()+900) );
				}
			},
			startRecieve => sub
			{
				$_[HEAP]->{'socket'} = new POE::Wheel::ReadWrite
				(
					Handle     => $socket,
					InputEvent => 'gotline',
					ErrorEvent => 'goterror',
			    );
			},
			sendLoop => sub
			{
				return if ( $_[HEAP]->{'connected'} != 1 );
				
				# Limit message length to 1024 characters
				my $availableChars = 1024;
				my $sendString = "";
				
				# Send at least one message
				if ( $messageQueue[0] )
				{
					my $output = shift @messageQueue;
					$sendString .= $output;
					$availableChars -= length ( $output );
					
					# Keep sending messages until we hit our chars per second limit
					while ( $messageQueue[0] && ( length($messageQueue[0]) < $availableChars ) )
					{
						$output = shift @messageQueue;
						$sendString .= $output;
						$availableChars -= length ( $output );
					}
				}	
				
				# If there's anything to send then send it
				if ( $sendString ) { $socket->send( $sendString ); }
			    
			    # Come back to the send loop in 1 second
			   $_[KERNEL]->delay ( "sendLoop", 1 );
			},
			gotline => sub
			{
				my ( $input ) = @_[ ARG0 ];
				
				#open ( IPBOTDEBUGFILE, '>>ipbotdebug.txt' );
				#print IPBOTDEBUGFILE "RECEIVE: $input\n";
				#close IPBOTDEBUGFILE;
				
				# Do something with input
				parseInput ( $input );
			},
			goterror => sub		# Means we are disconnected
			{
				my ( $error, $errorCode, $errorString ) = @_[ ARG0, ARG1, ARG2 ];
				
				#open ( IPBOTDEBUGFILE, '>>ipbotdebug.txt' );
				#print IPBOTDEBUGFILE "ERROR: $error\n";
				#close IPBOTDEBUGFILE;
				
				$_[HEAP]->{'connected'} = 0;
				
				# Shutdown socket and wheel
				$_[HEAP]->{'socket'}->shutdown_input();
				$_[HEAP]->{'socket'}->shutdown_output();
				delete $_[HEAP]->{'socket'};
				shutdown ( $socket, 2 );
				
				plugin::ircmsg ( "The IPBot server has gone offline.", "A" );
				print "IPBOT ERROR: Error during $error. Error code $errorCode: $errorString\n";
				print "IPBOT: Disconnect detected, attemping to reconnect in 20 seconds.\n";
				$_[KERNEL]->alarm ( "reconnect" => (time()+20) );
			}
		}
	);
}


sub stop
{}


# Command event - Triggers on any !command which is in this plugins XML file
sub command
{
	my ( $kernel, $args ) = @_[ KERNEL, ARG0 ];
	my %args = %{$args};
	
	# Trigger the event with the same name as the command
	$kernel->yield ( $args{'command'} => \%args );
}


# Playerjoin event
sub playerjoin
{
	my ( $kernel, $args ) = @_[ KERNEL, ARG0 ];
	my %args = %{$args};
	
	# Schedule them to be reported to the server in 3 seconds
	# Gives BRenBot time to get their IP
	$kernel->alarm( reportPlayerData => (int(time()) +3) => $args{'nick'} );
}


# # Text event, used when in irc communication mode.
# sub text
# {
# 	# Triggered on any text from irc or ingame
# 	my ( $args ) = @_[ ARG0 ];
# 	my %args = %{$args};
# 	
# 	# Return if ipbotMode != 2 (IRC connection), or the message is not an irc_privmsg
# 	return if ( $config{'ipbotMode'} != 2 || $args{'messagetype'} ne "irc_privmsg" );
# 	
# 	
# 	# Results for stats requests
# 	if ( $args{'message'} =~ m/^830 (\d+) (\d+) (\d+)/i )
# 	{
# 		plugin::ircmsg ( "There are currently $1 records in the ipbot's database, consisting of $2 unique player nicknames and $3 unique ip addresses.", $args{'ircChannelCode'} );
# 	}
# 	
# 	
# 	# Response to status requests
# 	if ( $args{'message'} =~ m/^839$/i )
# 	{
# 		$recievedStatusReply = 1;
# 	}
# 	
# 	
# 	# Results for ip seaches
# 	if ( $args{'message'} =~ m/^831 (\d+) (\d+)/i )
# 	{
# 		if ( $1 ne $2 )
# 		{
# 			plugin::ircmsg ( "Found $2 results for your search, displaying first $1 results.", $args{'ircChannelCode'} );
# 		}
# 		elsif ( $1 eq '0' )
# 		{
# 			plugin::ircmsg ( "Unable to find any records matching your search term.", $args{'ircChannelCode'} );
# 		}
# 		else
# 		{
# 			plugin::ircmsg ( "Found $2 results for your search, displaying all results.", $args{'ircChannelCode'} );
# 		}
# 	}
# 	
# 	
# 	elsif ( $args{'message'} =~ m/^832 (\d+\.\d+\.\d+\.\d+) (.+)/i )
# 	{
# 		my $message = "7 ".$1.": ( ";
# 		
# 		$2 =~ m/^([^:]+):(\d+)(.+)?/i;
# 		$message .= "$1 (".modules::get_past_date_time ( "DD/MM/YY", $2 ).")";
# 		
# 		# Process any extra names's
# 		my $loopCount = 0;
# 		while ( length($3) > 0 && $loopCount <= 15 )
# 		{
# 			$3 =~ m/^, ([^:]+):(\d+)(.+)?/i;
# 			$message .= ", $1 (".modules::get_past_date_time ( "DD/MM/YY", $2 ).")";
# 			$loopCount++;
# 		}
# 		
# 		$message .= " )";
# 		
# 		plugin::ircmsg ( $message, $args{'ircChannelCode'} );
# 	}
# 	
# 	
# 	# Results for nick searches
# 	elsif ( $args{'message'} =~ m/^833 (\d+) (\d+)/i )
# 	{
# 		if ( $1 ne $2 )
# 		{
# 			plugin::ircmsg ( "Found $2 results for your search, displaying first $1 results.", $args{'ircChannelCode'} );
# 		}
# 		elsif ( $1 eq '0' )
# 		{
# 			plugin::ircmsg ( "Unable to find any records matching your search term.", $args{'ircChannelCode'} );
# 		}
# 		else
# 		{
# 			plugin::ircmsg ( "Found $2 results for your search, displaying all results.", $args{'ircChannelCode'} );
# 		}
# 	}
# 	
# 	
# 	elsif ( $args{'message'} =~ m/^834 ([^.]+) (\d+\.\d+\.\d+\.\d+.+)/i )
# 	{
# 		my $message = "7 ".$1.": ( ";
# 		
# 		$2 =~ m/^(\d+\.\d+\.\d+\.\d+):(\d+)(.+)?/i;
# 		$message .= "$1 (".modules::get_past_date_time ( "DD/MM/YY", $2 ).")";
# 		
# 		# Process any extra ip's
# 		while ( length($3) > 0 )
# 		{
# 			$3 =~ m/^, (\d+\.\d+\.\d+\.\d+):(\d+)(.+)?/i;
# 			$message .= ", $1 (".modules::get_past_date_time ( "DD/MM/YY", $2 ).")";
# 		}
# 		
# 		$message .= " )";
# 		
# 		plugin::ircmsg ( $message, $args{'ircChannelCode'} );
# 	}
# }



####################################
##
# Data Input
#
# Parsing data recieved back from the server
##
####################################

# Parses data recieved from the IPBot server via the socket
sub parseInput
{
	my $input = shift;
	
	if ( $input =~ m/^721\s(.+)/ )
		{ process_721($1); }
	#if ( $input =~ m/^722\s(.+)/ )
	#	{ process_722($1); }
	if ( $input =~ m/^723\s(.+)/ )
		{ process_723($1); }
	if ( $input =~ m/^724\s(.+)/ )
		{ process_724($1); }
}


# Process 721 input ( Stats response )
# 721 reqID:records:names:ips		Stats Response
sub process_721
{
	my $input = shift;
	
	if ( $input =~ m/(\d+)\:(\d+)\:(\d+)\:(\d+)/ )
	{
		plugin::ircmsg ( "There are currently $2 records in the IPBot database, consisting of $3 unique nicknames and $4 unique IPs", "A" );
	}
}


# Process 723 input ( IP Search Result )
# 723 reqID:found:sending ip Tstmp:name\tTstmp:name\0ip Tstmp:name\tTstmp:name\0	ip search result
sub process_723
{
	my $input = shift;
	
	if ( $input =~ m/(\d+)\:(\d+)\:(\d+)\s(.+)/ )
	{
		plugin::ircmsg ( "Found $3 results for your search, showing first $2...", "A" );
		
		my $results = $4;
		while ( $results =~ m/\s*(\S+)\s([^\]+)((.+))?/ )
		{
			$results = $4;
			# 1 = ip
			# 2 = group of names / timestamps
			my $message = "07$1: ( ";
			
			my $names = $2;
			while ( $names =~ m/\s*(\d+)\:([^\t]+)(\t.+)?/ )
			{
				$names = $3;
				$message .= "$2 (".modules::get_past_date_time ( "DD/MM/YY", $1 )."), ";
			}
			
			# Trim trailing ', '
			$message = substr ( $message, 0, -2 );
			
			$message .= " )";
			
			plugin::ircmsg ( $message, "A" );
		}
	}
	else
	{
		plugin::ircmsg ( "No results found for your search" );
	}
}



# Process 724 input ( IP Search Result )
# 724 reqID:found:sending name Tstmp:ip\tTstmp:ip\0name Tstmp:ip\tTstmp:ip\0	name search result
sub process_724
{
	my $input = shift;
	
	if ( $input =~ m/(\d+)\:(\d+)\:(\d+)\s(.+)/ )
	{
		plugin::ircmsg ( "Found $3 results for your search, showing first $2...", "A" );
		
		my $results = $4;
		while ( $results =~ m/\s*([^\ ]+)\s([^\]+)((.+))?/ )
		{
			$results = $4;
			# 1 = ip
			# 2 = group of names / timestamps
			my $message = "07$1: ( ";
			
			my $ips = $2;
			while ( $ips =~ m/\s*(\d+)\:([^\t]+)(\t.+)?/ )
			{
				$ips = $3;
				$message .= "$2 (".modules::get_past_date_time ( "DD/MM/YY", $1 )."), ";
			}
			
			# Trim trailing ', '
			$message = substr ( $message, 0, -2 );
			
			$message .= " )";
			
			plugin::ircmsg ( $message, "A" );
		}
	}
	else
	{
		plugin::ircmsg ( "No results found for your search" );
	}
}




####################################
##
# Other Functions
#
# N/A
##
####################################

# Triggered by the timer on playerjoin event, gets the IP of the player ( if they
# are still ingame ) and reports it to the server
sub reportPlayerData
{
	my ( $kernel, $playername ) = @_[ KERNEL, ARG0 ];
	
	# Get and send the info for the player
	my ( $result, %player ) = plugin::getPlayerData( $playername );
	if ( $result == 1 && $serverOnline == 1 && $player{'ip'} )
	{
		# Report them to the ipbot server - request ID 0 (we dont need a reply)
		sendToServer ( "702 00:" . $player{'ip'} . ":" . $player{'name'} );
	}
}

# Scan's and reports all players in game, used when the bot has just loaded so nobody
# gets missed out. Also starts regular scans for players. Scans players in groups of
# three to prevent excessive network traffic.
my $lastScannedID = 0;		# Static variable for scanning function
sub scanPlayers
{
	my ( $kernel ) = @_[ KERNEL ];
	
	if ( $serverOnline == 1 )
	{
		my $playersProcessed = 0;
		
		my %playerlist = plugin::get_playerlist();
		while ( my ( $id, $player ) = each ( %playerlist ) )
		{
			next if ( $id <= $lastScannedID );			# Skip to where we left off
			if ( $playersProcessed == 3 ) { last; }		# Dont do more than 3 players
			
			# Report them to the ipbot server
			if ( $player->{'ip'} )
			{
				# Report them to the ipbot server - request ID 0 (we dont need a reply)
				sendToServer ( "702 00:" . $player{'ip'} . ":" . $player{'name'} );
				$lastScannedID = $id;
				$playersProcessed++;
			}
		}
		
		# If we reached the end of the playerlist loop back to start
		if ( $playersProcessed < 3 ) { $lastScannedID = 0; }
	}
	
	# Schedule another scan in 2 minutes (tcp mode) or 10 minutes (irc mode)
	my $delay = ( $config{'botMode'} == 1 ) ? 120 : 1200;
	$kernel->alarm( scanPlayers => (int(time()) +$delay) );
}


# Sends data to the ipbot server
sub sendToServer
{
	my $line = shift;
	
	#if ( $config{'ipbotMode'} == 1 )			# Socket Mode
	#{
		push ( @messageQueue, "$line\n" );
	#}
	#elsif ( $config{'ipbotMode'} == 2 )			# IRC Mode (nickname IPBot on irc server)
	#	{ $poe_kernel->post( IRC => privmsg => IPBot, shift ); }
}


# Return true or the bot will not work properly...
1;