<?

  include "config.php";

$fullurl = "".$Mainurl."signature.php?";
if ($player) $fullurl .= "player=".$player."&";
if ($image) $fullurl .= "image=".$image."&";
if ($imgurl) $fullurl .= "imgurl=".$imgurl."&";
if ($colour) $fullurl .= "colour=".$colour."";

?>

<html>

<head>
  <title>Dynamic Image Generator</title>
</head>

<body bgcolor='#C0C0C0' link='#000000' vlink='#000000' alink='#000000'>

<div align='center'>
  <center>
  <table border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='90%' height='100%' bgcolor='#FFFFFF'>
    <tr>
      <td width='80%' height='100%'>
      <p align="center"><br><br><font size="3" face="Lucida Console">Stats Image Generator</font></p>
      <p><form action='create.php' method='post'>
  <table align='center' valign='top'>
    <tr>
      <td align='right'><font face="Tahoma">Name</font></td>
      <td align='left'><input type='text'  value='' name='player' size='30'></td>
    </tr>

    <tr>
      <td align='right'>
      <font face="Tahoma"><BR>Image:</td>
      <td align='left'><BR>
       <select name='image'>
          <option value='nod' selected>Nod</option>
          <option value='gdi'>GDI</option>
          <option value='users'>Own Image</option>
        </select> </td>
    </tr>

    <tr>
      <td align='right'><font face="Tahoma">Image URL </font></td>
      <td align='left'><input type='text'  value='' name='imgurl' size='30'></td>
    </tr>

    <tr>
      <td align='right'>
      <font face="Tahoma"><BR>Font to use:</td>
      <td align='left'><BR>
       <select name='colour'>
          <option value='black'>Black</option>
          <option value='white' selected>White</option>
        </select> </td>
    </tr>
    
<? if ($send == "1") { ?>
    <tr>
      <td colspan='2'> </td>
    </tr>
    <tr>
      <td align='right'><font face='Tahoma'>Final Image:</font></td>
      <td align='left'><img src='<? echo $fullurl; ?>'></td></tr>
    <tr>
      <td align='right'><font face='Tahoma'>URL:</font></td>
      <td align='left'><input type='text'  value='[img]<? echo $fullurl; ?>[/img]' name='link' size='70'></td>
    </tr>
<? } ?>
    <tr>
     <td align='center' colspan='2'><br><input type='hidden' name='send' value='1'><input type='submit' value='Create'><br><br></td>
    </tr>
  </table>
</form>
</td>
  </center>
</div>

</div>

</body>

</html>