<?php

 include "config.php";

 if ( !$ranksTXT = file_get_contents ( "".$RanksFile."" ) )
  {
    mysql_query("truncate table ranks");
    echo"<div class='white'>Ranks table seems to be empty :(</div>";
  }
 
 else
  {
   mysql_query("truncate table ranks");

    $playersArray = explode( "\n", $ranksTXT);
    $arraysize = sizeof($playersArray) -1;

    for ( $i = 0; $i < $arraysize; $i++)
    {
    $playersArray[$i] = explode ( "\t", $playersArray[$i] );
    
    //basic stats
    $rank   = trim($playersArray[$i][0]);
    $playername   = str_replace ( "'", "\'", trim($playersArray[$i][1]) );
    $totalkills  = trim($playersArray[$i][2]);
    $totaldeaths  = trim($playersArray[$i][3]);
    $totalscore = trim($playersArray[$i][4]);
    $mvp   = trim($playersArray[$i][5]);
    $games  = trim($playersArray[$i][6]);
    $gdi  = trim($playersArray[$i][7]);
    $nod  = trim($playersArray[$i][8]);
    //kills and repairs
    $bkills  = trim($playersArray[$i][9]);
    $breps  = trim($playersArray[$i][10]);
    $vkills = trim($playersArray[$i][11]);
    $vreps   = trim($playersArray[$i][12]);
    //vehicles
    $nodharv  = trim($playersArray[$i][13]);
    $nodbug  = trim($playersArray[$i][14]);
    $nodapc  = trim($playersArray[$i][15]);
    $nodart  = trim($playersArray[$i][16]);
    $nodlight  = trim($playersArray[$i][17]);
    $nodflame  = trim($playersArray[$i][18]);
    $nodstank  = trim($playersArray[$i][19]);
    $nodapache  = trim($playersArray[$i][20]);
    $nodtrans  = trim($playersArray[$i][21]);
    $gdiharv  = trim($playersArray[$i][22]);
    $gdihum  = trim($playersArray[$i][23]);
    $gdiapc  = trim($playersArray[$i][24]);
    $gdimrl  = trim($playersArray[$i][25]);
    $gdimed  = trim($playersArray[$i][26]);
    $gdimam  = trim($playersArray[$i][27]);
    $gdiorca  = trim($playersArray[$i][28]);
    $gditrans  = trim($playersArray[$i][29]);
    //buildings
    $nodhon  = trim($playersArray[$i][30]);
    $nodref  = trim($playersArray[$i][31]);
    $nodobi  = trim($playersArray[$i][32]);
    $nodpp  = trim($playersArray[$i][33]);
    $nodair  = trim($playersArray[$i][34]);
    $gdibar  = trim($playersArray[$i][35]);
    $gdiref  = trim($playersArray[$i][36]);
    $gdiagt  = trim($playersArray[$i][37]);
    $gdipp  = trim($playersArray[$i][38]);
    $gdiwf  = trim($playersArray[$i][39]);

    //total kd ratio;
    if ($totaldeaths == 0) { $totaldeaths = 1; }
     $totalkd = $totalkills /$totaldeaths;

    //repair points
    $repairpoints = $breps +$vreps;
    
    //building totals
    $gdibkills = $gdibar +$gdiref +$gdiagt +$gdipp +$gdiwf; 
    $nodbkills = $nodhon +$nodref +$nodobi +$nodpp +$nodair; 

    //vehicle totals
    $gdivkills = $gdiharv +$gdihum +$gdiapc +$gdimrl +$gdimed +$gdimam +$gdiorca +$gditrans;
    $nodvkills = $nodharv +$nodbug +$nodapc +$nodart +$nodlight +$nodflame +$nodstank +$nodapache +$nodtrans;

    //total rank points
    $rank_breppoints = $breps/$breppoints;
    $rank_bkillpoints = $bkills/$bkillpoints;
    $rank_vreppoints = $vreps/$vreppoints;
    $rank_vkillpoints = $vkills/$vkillpoints;
    $rank_killspoints = $totalkills/$killspoints;
    $rank_deathspoints = $totaldeaths/$deathspoints;
    $rank_scorepoints = $totalscore/$scorepoints;
    $rankpoints = round(($rank_breppoints+$rank_bkillpoints+$rank_vreppoints+$rank_vkillpoints+$rank_killspoints+$rank_scorepoints)-$rank_deathspoints);

mysql_query("INSERT INTO ranks(
               rank,
               playername,
               totalkills,
               totaldeaths,
               totalkd,
               totalscore,
               mvp,
               games,  
               gdi, 
               nod, 
               bkills, 
               breps, 
               vkills, 
               vreps, 
               nodharv, 
               nodbug, 
               nodapc, 
               nodart, 
               nodlight, 
               nodflame, 
               nodstank, 
               nodapache, 
               nodtrans, 
               gdiharv, 
               gdihum, 
               gdiapc, 
               gdimrl, 
               gdimed, 
               gdimam, 
               gdiorca, 
               gditrans, 
               nodhon, 
               nodref, 
               nodobi, 
               nodpp, 
               nodair, 
               gdibar, 
               gdiref, 
               gdiagt, 
               gdipp, 
               gdiwf,
               rankpoints,
               repairpoints,
               gdibkills,
               nodbkills,
               gdivkills,
               nodvkills
               ) 

VALUES(
     '".$rank."',
     '".$playername."',
     '".$totalkills."',
     '".$totaldeaths."', 
     '".$totalkd."', 
     '".$totalscore."',
     '".$mvp."',
     '".$games."',
     '".$gdi."',
     '".$nod."',
     '".$bkills."',
     '".$breps."',
     '".$vkills."',
     '".$vreps."',
     '".$nodharv."',
     '".$nodbug."',
     '".$nodapc."',
     '".$nodart."',
     '".$nodlight."',
     '".$nodflame."',
     '".$nodstank."',
     '".$nodapache."',
     '".$nodtrans."',
     '".$gdiharv."',
     '".$gdihum."',
     '".$gdiapc."',
     '".$gdimrl."',
     '".$gdimed."',
     '".$gdimam."',
     '".$gdiorca."',
     '".$gditrans."',
     '".$nodhon."',
     '".$nodref."',
     '".$nodobi."',
     '".$nodpp."',
     '".$nodair."',
     '".$gdibar."',
     '".$gdiref."',
     '".$gdiagt."',
     '".$gdipp."',
     '".$gdiwf."',
     '".$rankpoints."',
     '".$repairpoints."',
     '".$gdibkills."',
     '".$nodbkills."',
     '".$gdivkills."',
     '".$nodvkills."')") or die(mysql_error());

   }
}
echo"updated";
?>