<?php

//sql config

  $hostname  = "localhost";
  $username  = "dbuser";
  $password  = "dbpass";
  $database  = "ranks";

  mysql_connect("$hostname","$username","$password");
  mysql_select_db("$database");

// rank stats config

// this is the same config that is in your ranks.xml
  
  $RanksFile="ranks.txt";
  $breppoints = 1000;
  $bkillpoints = 0.5;
  $vreppoints = 1200;
  $vkillpoints = 3;
  $killspoints = 10;
  $deathspoints = 12;
  $scorepoints = 1500;

// GD image sig

  $FontFile="arial.ttf";
  $GDIImage="images/gdi.png";
  $NodImage="images/nod.png";
  $DefaultImage="images/Default.png";
  $Mainurl="http://www.example.net/ranks/";

?>