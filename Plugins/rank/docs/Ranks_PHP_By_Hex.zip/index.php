<html>
<head>
<title>Server Ranks</title>

	<!-- no cache headers -->
	<meta http-equiv='Pragma' content='no-cache' />
	<meta http-equiv='Expires' content='-1' />
	<meta http-equiv='Cache-Control' content='no-cache' />
	<!-- end no cache headers -->
<link rel='stylesheet' type='text/css' media='screen' title='User Defined Style' href='style.css' />
</head>
<body>
<table class='fborder' cellpadding='6' cellspacing='1' width='100%'>

<tr>	
  <td class='form'>
<form action='?search' method='post'>
Search: <input type='text' id='srchbox' name='keywords' size='20' maxlength='40' value='' />
<input type='submit' id='srchbt' value='Find' />
</form></td>
  <td class='form'><form action='?order' method='post'>
  Sort: <select class='txtbox' name='sort'>
  <option  value='mvp'>Sort by MVP</option> 
  <option  value='gdi'>Sort by GDI</option> 
  <option  value='nod'>Sort by Nod</option> 
  <option  value='games'>Sort by most Games</option>
  <option  value='totalkills'>Sort by most Kills</option> 
  <option  value='totaldeaths'>Sort by most Deaths</option> 
  <option  value='vkills'>Sort by Vehicles destroyed</option> 
  <option  value='bkills'>Sort by Buildings destroyed</option> 
  </select>
 <input type='submit' class='button' value='Sort' id='srchbt'>
  </form>
</td>
  </tr>
</table>
<table class='fborder' cellpadding='6' cellspacing='1' width='100%'>
<tr>	
  <td class='form'>
Click a Players name for more detailed information
</td>
</table>
<?php

 include "config.php";



echo"<table class='tborder' cellpadding='6' cellspacing='1' width='100%'>

  <tr>
   <td class='thead'>Rank</td>
   <td class='thead'>Points</td>
   <td class='thead' width='100%'>Name</td>
   <td class='thead'>Score</td>
   <td class='thead'>kills</td>
   <td class='thead'>Deaths</td>
   <td class='thead'>K/D</td>
   <td class='thead'>Team</td>
   <td class='thead'>Buildings Destroyed</td>
   <td class='thead'>Vehicles Destroyed</td>
   <td class='thead'>MVP</td>
   <td class='thead'>Games</td>
 </tr>";

if(isset($update)) {
//   echo"<div class='white'>updating database...<div>";
  if ( !$ranksTXT = file_get_contents ( "".$RanksFile."" ) )
  {
    mysql_query("truncate table ranks");
    echo"<div class='white'>Ranks table seems to be empty :(</div>";
  }
 
 else
  {
   mysql_query("truncate table ranks");

    $playersArray = explode( "\n", $ranksTXT);
    $arraysize = sizeof($playersArray) -1;

    for ( $i = 0; $i < $arraysize; $i++)
    {
    $playersArray[$i] = explode ( "\t", $playersArray[$i] );
    
    //basic stats
    $rank   = trim($playersArray[$i][0]);
    $playername   = str_replace ( "'", "\'", trim($playersArray[$i][1]) );
    $totalkills  = trim($playersArray[$i][2]);
    $totaldeaths  = trim($playersArray[$i][3]);
    $totalscore = trim($playersArray[$i][4]);
    $mvp   = trim($playersArray[$i][5]);
    $games  = trim($playersArray[$i][6]);
    $gdi  = trim($playersArray[$i][7]);
    $nod  = trim($playersArray[$i][8]);
    //kills and repairs
    $bkills  = trim($playersArray[$i][9]);
    $breps  = trim($playersArray[$i][10]);
    $vkills = trim($playersArray[$i][11]);
    $vreps   = trim($playersArray[$i][12]);
    //vehicles
    $nodharv  = trim($playersArray[$i][13]);
    $nodbug  = trim($playersArray[$i][14]);
    $nodapc  = trim($playersArray[$i][15]);
    $nodart  = trim($playersArray[$i][16]);
    $nodlight  = trim($playersArray[$i][17]);
    $nodflame  = trim($playersArray[$i][18]);
    $nodstank  = trim($playersArray[$i][19]);
    $nodapache  = trim($playersArray[$i][20]);
    $nodtrans  = trim($playersArray[$i][21]);
    $gdiharv  = trim($playersArray[$i][22]);
    $gdihum  = trim($playersArray[$i][23]);
    $gdiapc  = trim($playersArray[$i][24]);
    $gdimrl  = trim($playersArray[$i][25]);
    $gdimed  = trim($playersArray[$i][26]);
    $gdimam  = trim($playersArray[$i][27]);
    $gdiorca  = trim($playersArray[$i][28]);
    $gditrans  = trim($playersArray[$i][29]);
    //buildings
    $nodhon  = trim($playersArray[$i][30]);
    $nodref  = trim($playersArray[$i][31]);
    $nodobi  = trim($playersArray[$i][32]);
    $nodpp  = trim($playersArray[$i][33]);
    $nodair  = trim($playersArray[$i][34]);
    $gdibar  = trim($playersArray[$i][35]);
    $gdiref  = trim($playersArray[$i][36]);
    $gdiagt  = trim($playersArray[$i][37]);
    $gdipp  = trim($playersArray[$i][38]);
    $gdiwf  = trim($playersArray[$i][39]);

    //total kd ratio;
    if ($totaldeaths == 0) { 
        $totaldeaths = 1; 
    }
     $totalkd = $totalkills /$totaldeaths;

    //repair points
    $repairpoints = $breps +$vreps;
    
    //building totals
    $gdibkills = $gdibar +$gdiref +$gdiagt +$gdipp +$gdiwf; 
    $nodbkills = $nodhon +$nodref +$nodobi +$nodpp +$nodair; 

    //vehicle totals
    $gdivkills = $gdiharv +$gdihum +$gdiapc +$gdimrl +$gdimed +$gdimam +$gdiorca +$gditrans;
    $nodvkills = $nodharv +$nodbug +$nodapc +$nodart +$nodlight +$nodflame +$nodstank +$nodapache +$nodtrans;

    //total rank points
    $rank_breppoints = $breps/$breppoints;
    $rank_bkillpoints = $bkills/$bkillpoints;
    $rank_vreppoints = $vreps/$vreppoints;
    $rank_vkillpoints = $vkills/$vkillpoints;
    $rank_killspoints = $totalkills/$killspoints;
    $rank_deathspoints = $totaldeaths/$deathspoints;
    $rank_scorepoints = $totalscore/$scorepoints;
    $rankpoints = round(($rank_breppoints+$rank_bkillpoints+$rank_vreppoints+$rank_vkillpoints+$rank_killspoints+$rank_scorepoints)-$rank_deathspoints);

mysql_query("INSERT INTO ranks(
               rank,
               playername,
               totalkills,
               totaldeaths,
               totalkd,
               totalscore,
               mvp,
               games,  
               gdi, 
               nod, 
               bkills, 
               breps, 
               vkills, 
               vreps, 
               nodharv, 
               nodbug, 
               nodapc, 
               nodart, 
               nodlight, 
               nodflame, 
               nodstank, 
               nodapache, 
               nodtrans, 
               gdiharv, 
               gdihum, 
               gdiapc, 
               gdimrl, 
               gdimed, 
               gdimam, 
               gdiorca, 
               gditrans, 
               nodhon, 
               nodref, 
               nodobi, 
               nodpp, 
               nodair, 
               gdibar, 
               gdiref, 
               gdiagt, 
               gdipp, 
               gdiwf,
               rankpoints,
               repairpoints,
               gdibkills,
               nodbkills,
               gdivkills,
               nodvkills
               ) 

VALUES(
     '".$rank."',
     '".$playername."',
     '".$totalkills."',
     '".$totaldeaths."', 
     '".$totalkd."', 
     '".$totalscore."',
     '".$mvp."',
     '".$games."',
     '".$gdi."',
     '".$nod."',
     '".$bkills."',
     '".$breps."',
     '".$vkills."',
     '".$vreps."',
     '".$nodharv."',
     '".$nodbug."',
     '".$nodapc."',
     '".$nodart."',
     '".$nodlight."',
     '".$nodflame."',
     '".$nodstank."',
     '".$nodapache."',
     '".$nodtrans."',
     '".$gdiharv."',
     '".$gdihum."',
     '".$gdiapc."',
     '".$gdimrl."',
     '".$gdimed."',
     '".$gdimam."',
     '".$gdiorca."',
     '".$gditrans."',
     '".$nodhon."',
     '".$nodref."',
     '".$nodobi."',
     '".$nodpp."',
     '".$nodair."',
     '".$gdibar."',
     '".$gdiref."',
     '".$gdiagt."',
     '".$gdipp."',
     '".$gdiwf."',
     '".$rankpoints."',
     '".$repairpoints."',
     '".$gdibkills."',
     '".$nodbkills."',
     '".$gdivkills."',
     '".$nodvkills."')") or die(mysql_error());

   }
   
   echo"<meta http-equiv=Refresh content=1;url='?'>";
   }
   } 
elseif(isset($search)) {

   $fetch = mysql_query("SELECT * FROM `ranks` WHERE playername like '%$keywords%' ORDER BY totalscore DESC limit 50");

  if (isset($_POST['keywords'])) {
     if($keywords == "")
  echo"<tr>
  <td class='rank'></td>	
  <td class='rankpoints'></td>
  <td class='name'>You need to put some term to search for.</td>	
  <td class='score'></td>
  <td class='kills'></td>	
  <td class='deaths'></td>	
  <td class='kd'></td>
  <td class='team'></td>
  <td class='building'></td>
  <td class='vehicle'></td>
  <td class='mvp'></td>
  <td class='games'></td>		
  </tr>"; 
    elseif(mysql_fetch_object($fetch) == false) {
  echo"<tr>
  <td class='rank'></td>
  <td class='rankpoints'></td>	
  <td class='name'>No results found for '<b>$keywords</b>'</td>	
  <td class='score'></td>
  <td class='kills'></td>	
  <td class='deaths'></td>	
  <td class='kd'></td>
  <td class='team'></td>
  <td class='building'></td>
  <td class='vehicle'></td>
  <td class='mvp'></td>
  <td class='games'></td>		
  </tr>"; 
      }
    else 
   {
   $keywords = addslashes($_POST['keywords']);
   $fetch = mysql_query("SELECT * FROM `ranks` WHERE playername like '%$keywords%' ORDER BY totalscore DESC limit 50");
     while($myrow = mysql_fetch_object($fetch)) {
		
 echo"<tr>
  <td class='rank'>$myrow->rank</td>
  <td class='rankpoints'>$myrow->rankpoints</td>	
  <td class='name'><a href=\"ranks_extended.php?pid=$myrow->playername\">$myrow->playername</a></td>	
  <td class='score'>$myrow->totalscore</td>
  <td class='kills'>$myrow->totalkills</td>	
  <td class='deaths'>$myrow->totaldeaths</td>	
  <td class='kd'>$myrow->totalkd</td>
  <td class='team'><span style='color:#A29B22'>$myrow->gdi</span>/<span style='color:#660000'>$myrow->nod</span></td>
  <td class='building'><span style='color:#A29B22'>$myrow->gdibkills</span>/<span style='color:#660000'>$myrow->nodbkills</span></td>
  <td class='vehicle'><span style='color:#A29B22'>$myrow->gdivkills</span>/<span style='color:#660000'>$myrow->nodvkills</span></td>
  <td class='mvp'>$myrow->mvp</td>	
  <td class='games'>$myrow->games</td>	
  </tr>";  
 }
}
}
}
elseif(isset($order)) {
   if(!isset($_GET['pagecount'])){ 
    $pagecount = 1; 
    } else { 
    $pagecount = $_GET['pagecount']; 
    } 
    $max_results = 50; 
    $from = (($pagecount * $max_results) - $max_results); 

   

    $total_results = mysql_result(mysql_query("SELECT COUNT(*) as Num FROM ranks"),0); 
    $total_pages = ceil($total_results / $max_results);
    $sort = addslashes($_POST['sort']);
    $fetch = mysql_query("SELECT * FROM `ranks` ORDER BY $sort DESC limit $from, $max_results");
     while($myrow = mysql_fetch_object($fetch)) {

   
  echo"<tr>
  <td class='rank'>$myrow->rank</td>
  <td class='rankpoints'>$myrow->rankpoints</td>	
  <td class='name'><a href=\"ranks_extended.php?pid=$myrow->playername\">$myrow->playername</a></td>	
  <td class='score'>$myrow->totalscore</td>
  <td class='kills'>$myrow->totalkills</td>	
  <td class='deaths'>$myrow->totaldeaths</td>	
  <td class='kd'>$myrow->totalkd</td>
  <td class='team'><span style='color:#A29B22'>$myrow->gdi</span>/<span style='color:#660000'>$myrow->nod</span></td>
  <td class='building'><span style='color:#A29B22'>$myrow->gdibkills</span>/<span style='color:#660000'>$myrow->nodbkills</span></td>
  <td class='vehicle'><span style='color:#A29B22'>$myrow->gdivkills</span>/<span style='color:#660000'>$myrow->nodvkills</span></td>
  <td class='mvp'>$myrow->mvp</td>	
  <td class='games'>$myrow->games</td>	
  </tr>";   
  }
  }
else { 
   if(!isset($_GET['pagecount'])){ 
    $pagecount = 1; 
    } else { 
    $pagecount = $_GET['pagecount']; 
    } 
    $max_results = 50; 
    $from = (($pagecount * $max_results) - $max_results); 

    $total_results = mysql_result(mysql_query("SELECT COUNT(*) as Num FROM ranks"),0); 
    $total_pages = ceil($total_results / $max_results);
    $fetch = mysql_query("SELECT * FROM `ranks` ORDER BY rank ASC limit $from, $max_results");
     while($myrow = mysql_fetch_object($fetch)) {

   
  echo"<tr>
  <td class='rank'>$myrow->rank</td>
  <td class='rankpoints'>$myrow->rankpoints</td>	
  <td class='name'><a href=\"ranks_extended.php?pid=$myrow->playername\">$myrow->playername</a></td>	
  <td class='score'>$myrow->totalscore</td>
  <td class='kills'>$myrow->totalkills</td>	
  <td class='deaths'>$myrow->totaldeaths</td>	
  <td class='kd'>$myrow->totalkd</td>	
  <td class='team'><span style='color:#A29B22'>$myrow->gdi</span>/<span style='color:#660000'>$myrow->nod</span></td>
  <td class='building'><span style='color:#A29B22'>$myrow->gdibkills</span>/<span style='color:#660000'>$myrow->nodbkills</span></td>
  <td class='vehicle'><span style='color:#A29B22'>$myrow->gdivkills</span>/<span style='color:#660000'>$myrow->nodvkills</span></td>
  <td class='mvp'>$myrow->mvp</td>	
  <td class='games'>$myrow->games</td>		
  </tr>";   
  }
  } 
  echo"</table><table class='links' cellpadding='6' cellspacing='1' width='100%'>";
  echo"<td class='linkstd'>";
  if($pagecount > 1){ 
    $prev = ($pagecount - 1); 

    echo "<a href=\"".$_SERVER['PHP_SELF']."?pagecount=$prev\"><<Previous</a> &nbsp;"; 
    } for($i = 1; $i <= $total_pages; $i++){ 
    if(($pagecount) == $i){ 
    echo "$i&nbsp;"; 
    } else { 
    echo "<a href=\"".$_SERVER['PHP_SELF']."?pagecount=$i\">$i</a> &nbsp;"; 
    } 
   } 

  if($page < $total_pages){ 
    $next = ($pagecount + 1); 
    }  
?>
</td>
</table>
<table class='spacer' cellpadding='6' cellspacing='0' width='100%'>
<td>
  <tr>
   <td class='spacer'><center>Ranks 2.0 generated by BRenBot<br /><br />Design by Hex, n00bless.com</center></td>
  </tr>
</td>
</table>

   </body>
</html>

