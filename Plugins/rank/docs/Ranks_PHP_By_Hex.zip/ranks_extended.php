<html>
<head>
<title>Server Ranks</title>

	<!-- no cache headers -->
	<meta http-equiv='Pragma' content='no-cache' />
	<meta http-equiv='Expires' content='-1' />
	<meta http-equiv='Cache-Control' content='no-cache' />
	<!-- end no cache headers -->

<link rel='stylesheet' type='text/css' media='screen' title='User Defined Style' href='style.css' />
</head>
<body>

<?php

 include "config.php";

   $fetch = mysql_query("SELECT * FROM `ranks` WHERE playername='$pid' ");
     while($myrow = mysql_fetch_object($fetch)) {

    $rank_breppoints = round($myrow->breps/$breppoints, 2);
    $rank_bkillpoints = round($myrow->bkills/$bkillpoints, 2);
    $rank_vreppoints = round($myrow->vreps/$vreppoints, 2);
    $rank_vkillpoints = round($myrow->vkills/$vkillpoints, 2);
    $rank_killspoints = round($myrow->totalkills/$killspoints, 2);
    $rank_deathspoints = round($myrow->totaldeaths/$deathspoints, 2);
    $rank_scorepoints = round($myrow->totalscore/$scorepoints, 2);

echo"<div id='container'>

<table class='spacer' cellpadding='6' cellspacing='0' width='100%'>
<td>
  <tr>
   <td class='spacer'><center><a href=\"create.php\"><img src='signature.php?player=$myrow->playername' class='framed'></a></center></td>
  </tr>
</td>
</table>
<table class='tborder' cellpadding='1' cellspacing='1' width='100%'>
<td>
 <tr>	
	
  <td class='thead'>Buildings Destroyed</td>	
  <td class='thead'>Building repairs</td>
  <td class='thead'>Vehicles Destroyed</td>  
  <td class='thead'>Vehicle repairs</td>
  <td class='thead'>Total Points</td>
  </tr>
<tr>
  <td class='stats'>GDI: $myrow->gdibkills Nod: $myrow->nodbkills ($rank_bkillpoints Points)</td>	
  <td class='stats'>$myrow->breps ($rank_breppoints Points)</td>	
  <td class='stats'>GDI: $myrow->gdivkills Nod: $myrow->nodvkills ($rank_vkillpoints Points)</td>	
  <td class='stats'>$myrow->vreps ($rank_vreppoints Points)</td>	
  <td class='stats'>$myrow->rankpoints</td>		
  </tr>
</td>
</table>
<table class='spacer' cellpadding='6' cellspacing='0' width='100%'>
<td>
  <tr>
   <td class='spacer'></td>
  </tr>
</td>
</table>
<table class='tborder' cellpadding='1' cellspacing='1' width='100%'>
<td>
  <tr>
   <td class='thead'>Rank</td>
   <td class='thead'>Score</td>
   <td class='thead'>kills</td>
   <td class='thead'>Deaths</td>
   <td class='thead'>K/D</td>
   <td class='thead'>Games</td>
   <td class='thead'>GDI</td>
   <td class='thead'>Nod</td>
   <td class='thead'>MVP</td>
 </tr>
<tr>
  <td class='stats'>$myrow->rank</td>	
  <td class='stats'>$myrow->totalscore ($rank_scorepoints Points)</td>	
  <td class='stats'>$myrow->totalkills ($rank_killspoints Points)</td>	
  <td class='stats'>$myrow->totaldeaths (-$rank_deathspoints Points)</td>	
  <td class='stats'>$myrow->totalkd</td>
  <td class='stats'>$myrow->games</td>	
  <td class='stats'>$myrow->gdi</td>	
  <td class='stats'>$myrow->nod</td>	
  <td class='stats'>$myrow->mvp</td>	

  </tr>
</td>
</table>

<table class='spacer' cellpadding='6' cellspacing='0' width='100%'>
<td>
  <tr>
   <td class='spacer'></td>
  </tr>
</td>
</table>

<table class='tborder' cellpadding='1' cellspacing='1' width='100%'>
<td>
 <tr>	
  <td class='building'><img src='images/building_gdi_agt.jpg' class='framed'></td>
  <td class='building'><img src='images/building_gdi_fact.jpg' class='framed'></td>		
  <td class='building'><img src='images/building_gdi_inf.jpg' class='framed'></td>	
  <td class='building'><img src='images/building_gdi_power.jpg' class='framed'></td>
  <td class='building'><img src='images/building_gdi_ref.jpg' class='framed'></td>
  <td class='building'><img src='images/vehicle_gdi_harv.jpg' class='framed'></td>
  </tr>

<tr>
  <td class='stats'>$myrow->gdiagt</td>	
  <td class='stats'>$myrow->gdiwf</td>	
  <td class='stats'>$myrow->gdibar</td>	
  <td class='stats'>$myrow->gdipp</td>	
  <td class='stats'>$myrow->gdiref</td>	
  <td class='stats'>$myrow->gdiharv</td>	

  </tr>

 <tr>	
  <td class='building'><img src='images/vehicle_gdi_mamm.jpg' class='framed'></td>
  <td class='building'><img src='images/vehicle_gdi_med.jpg' class='framed'></td>		
  <td class='building'><img src='images/vehicle_gdi_mrl.jpg' class='framed'></td>	
  <td class='building'><img src='images/vehicle_gdi_orca.jpg' class='framed'></td>
  <td class='building'><img src='images/vehicle_gdi_trans.jpg' class='framed'></td>
  <td class='building'><img src='images/vehicle_gdi_apc.jpg' class='framed'></td>
  </tr>

<tr>
  <td class='stats'>$myrow->gdimam</td>	
  <td class='stats'>$myrow->gdimed</td>	
  <td class='stats'>$myrow->gdimrl</td>	
  <td class='stats'>$myrow->gdiorca</td>	
  <td class='stats'>$myrow->gditrans</td>	
  <td class='stats'>$myrow->gdiapc</td>	

  </tr>

 <tr>	
  <td class='building'><img src='images/vehicle_gdi_hum.jpg' class='framed'></td>
  <td class='building'></td>
  <td class='building'></td>
  <td class='building'></td>
  <td class='building'></td>
  <td class='building'></td>

  </tr>

<tr>
  <td class='stats'>$myrow->gdihum</td>
  <td class='stats'></td>
  <td class='stats'></td>
  <td class='stats'></td>
  <td class='stats'></td>
  <td class='stats'></td>	
	
  </tr>
</td>
</table>

<table class='spacer' cellpadding='6' cellspacing='0' width='100%'>
<td>
  <tr>
   <td class='spacer'></td>
  </tr>
</td>
</table>

<table class='tborder' cellpadding='1' cellspacing='1' width='100%'>
<td>
 <tr>	
  <td class='building'><img src='images/building_nod_ob.jpg' class='framed'></td>
  <td class='building'><img src='images/building_nod_air.jpg' class='framed'></td>		
  <td class='building'><img src='images/building_nod_hand.jpg' class='framed'></td>	
  <td class='building'><img src='images/building_nod_power.jpg' class='framed'></td>
  <td class='building'><img src='images/building_nod_ref.jpg' class='framed'></td>
  <td class='building'><img src='images/vehicle_nod_harv.jpg' class='framed'></td>
  </tr>

<tr>
  <td class='stats'>$myrow->nodobi</td>	
  <td class='stats'>$myrow->nodair</td>	
  <td class='stats'>$myrow->nodhon</td>	
  <td class='stats'>$myrow->nodpp</td>	
  <td class='stats'>$myrow->nodref</td>	
  <td class='stats'>$myrow->nodharv</td>	

  </tr>

 <tr>	
  <td class='building'><img src='images/vehicle_nod_flame.jpg' class='framed'></td>		
  <td class='building'><img src='images/vehicle_nod_stealth.jpg' class='framed'></td>
  <td class='building'><img src='images/vehicle_nod_light.jpg' class='framed'></td>	
  <td class='building'><img src='images/vehicle_nod_art.jpg' class='framed'></td>
  <td class='building'><img src='images/vehicle_nod_apache.jpg' class='framed'></td>
  <td class='building'><img src='images/vehicle_nod_trans.jpg' class='framed'></td>
  </tr>

<tr>
  <td class='stats'>$myrow->nodflame</td>	
  <td class='stats'>$myrow->nodstank</td>	
  <td class='stats'>$myrow->nodlight</td>	
  <td class='stats'>$myrow->nodart</td>	
  <td class='stats'>$myrow->nodapache</td>	
  <td class='stats'>$myrow->nodtrans</td>	

  </tr>

 <tr>	
  <td class='building'><img src='images/vehicle_nod_apc.jpg' class='framed'></td>
  <td class='building'><img src='images/vehicle_nod_buggy.jpg' class='framed'></td>
  <td class='building'></td>
  <td class='building'></td>
  <td class='building'></td>
  <td class='building'></td>

  </tr>

<tr>
  <td class='stats'>$myrow->nodapc</td>
  <td class='stats'>$myrow->nodbug</td>
  <td class='stats'></td>
  <td class='stats'></td>
  <td class='stats'></td>
  <td class='stats'></td>	
	
  </tr>
</td>
</table>

<table class='spacer' cellpadding='6' cellspacing='0' width='100%'>
<td>
  <tr>
   <td class='spacer'><center>Ranks 2.0 generated by BRenBot<br /><br />Design by Hex, n00bless.com</center></td>
  </tr>
</td>
</table>
</div>
   </body>
</html>";  
}

?>
