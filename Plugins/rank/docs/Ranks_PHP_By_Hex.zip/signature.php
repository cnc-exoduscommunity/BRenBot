<?php

  include "config.php";

  $player = "$_GET[player]";
  $imgurl = "$_GET[imgurl]";
  $colour = "$_GET[colour]";

  if ($image == gdi) $ImageURL="".$GDIImage."";
   elseif ($image == nod) $ImageURL="".$NodImage."";
   elseif ($image == users) $ImageURL="".$imgurl."";
   else $ImageURL="".$DefaultImage."";

   $checkname = mysql_query("SELECT * FROM ranks WHERE playername = '".$player."' LIMIT 1");
    
    if(mysql_num_rows($checkname) <1){
    
        $row1 = "No player data found";
    
    } else {
      
        while($data = mysql_fetch_object($checkname)) {

         $row1 = "Name: $data->playername Rank: $data->rank Score: $data->totalscore MVP: $data->mvp Rank Points: $data->rankpoints";
         $row2 = "Kills: $data->totalkills Deaths: $data->totaldeaths K/D: $data->totalkd Games: $data->games GDI: $data->gdi Nod: $data->nod";

      }

   }

   $TextX=5;
   $TextY=5;
   $size = ImageTTFBbox (15, 0, $FontFile, "meh");
   $im_x=abs($size[4]-$size[0]);
   $im_y=abs($size[5]-$size[1]);

  if (substr($ImageURL,strlen($ImageURL)-3,3)=="png") {
   Header("Content-type: image/png");
   Header("Expires: " . gmdate("D, d M Y H:i:s", time() + 900) . " GMT");

   $im_size = GetImageSize ($ImageURL);
   $imageWidth = $im_size[0];
   $imageHeight = $im_size[1];

   $im = ImageCreateFromPNG($ImageURL);

  if ($colour == white) $text_color = imagecolorclosest ($im, 255, 255, 255);
   elseif ($colour == black) $text_color = imagecolorclosest ($im, 0, 0, 0);
   else $text_color = imagecolorclosest ($im, 255, 255, 255);

  
      if ($TextX+$im_x>$imageWidth){$TextX=$imageWidth-$im_x-2;}
      if ($TextY>$imageHeight){$TextY=$imageHeight-2;}
      if($row1)imagettftext ($im, 10, 0, $TextX+10, $TextY+24, $text_color, $FontFile, $row1);
      if($row2)imagettftext ($im, 10, 0, $TextX+10, $TextY+47, $text_color, $FontFile, $row2);

    Imagepng ($im);
    ImageDestroy ($im);
}

?>
