Ranks php and GD signature for BRenBots ranks plugin 2.0


1.1

Added detailed rank points to all sections
Added detailed stats for Nod/GDI 
Added a K/D ratio
Complete recode of the GD signature code
Moved all the config settings to config.php
Cleaned up all code in general
Removed the update code from signature.php and added update.php (manual or cron updating) and added a updater in index.php (index.php?update)

1.0

First release

To install: Upload all the files to your web server, dump the database.sql in to your table and edit the config.php to your settings

Hex - http://www.n00bless.com

