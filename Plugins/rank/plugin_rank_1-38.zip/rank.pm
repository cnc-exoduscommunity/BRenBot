#
# RANK PLUGIN for BRenBot 1.51 by Daniel Paul
# Original plugin by PackHunter

# Version 1.38
#
package rank;

use POE;
use modules;
use plugin;
use strict;
use DBI;
use Net::FTP;

sub CHANNEL () { plugin::get_irc_channel() };

# define additional events in the POE session

our %additional_events =
(
	# Other Events
	"timer_expired" => "timer_expired",
	"process_results" => "process_results",
	"joinmessage" => "joinmessage",
	
	# !commands
	"rank" => "rank",
	"top" => "top",
	"rankstats" => "rankstats",
	"update" => "update",
	"rankIgnore" => "rankIgnore",
	"rankAllow" => "rankAllow",
	"rankMerge" => "rankMerge",
	"delRank" => "delRank"
);

# plugin_name and config are automatically given data by BRenBot
our $plugin_name;
our %config;
my $dbh;
my $dbVersion;
our $currentVersion = 1.38;
my %ignoredPlayers;			# Keep it in a hash to save checking in the db constantly
my $rankGame = 0;

########### Functions for !commands

# Function for !rank command - Shows rank for a player, or rank position
sub rank
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	# Create variables to hold results from get_rank
	my $result;					my %hash;
	
	if ( $args{nicktype} == 1 )
	{
		# We are running from IRC - check a parameter is given
		if ( !$args{arg1} ) { $kernel->post( IRC => privmsg => CHANNEL, "[BR] 7!rank is not allowed in IRC. Use !rank <name> or !rank <number>." ); }
		else
		{
			if( $args{arg1} =~ /^[0-9]+$/ ) { ( $result, %hash ) = get_rankPos($args{arg1}); }
			else { ( $result, %hash ) = get_rank( $args{arg1}, 0 ); }
			
			# Check if name provided is not unique ( result == 2 )
			if ( $result == 2 )
			{
				my $namesFound;
				while ( my ($key, $value) = each(%hash) ) { $namesFound .= "$value, "; }
				$namesFound = substr ( $namesFound, 0, -2 );			# Trim trailing ', '
				$kernel->post( IRC => privmsg => CHANNEL, "[BR]7 $args{arg1} was found in more than one name. The first " . keys(%hash) . " matches are :: $namesFound" );
			}
			
			# Now check if there was a result found
			elsif ( $result == 1 )
			{
				my $rankingData;
				if ( $config{rankMode} == 1 )
				{
					$rankingData = "$hash{points} points";
				}
				elsif ( $config{rankMode} == 2 )
				{
					$rankingData = "$hash{kills} kills";
				}
				elsif ( $config{rankMode} == 3 )
				{
					$rankingData = "a k/d of " . sprintf ( "%.1f", ( $hash{kills} / $hash{deaths} ) );
				}
				$kernel->post( IRC => privmsg => CHANNEL, "[BR]7 $hash{name} has $rankingData and is ranked at position $hash{rank} out of " . rankedPlayersCount() . " players." );
			}
			
			# No result found
			else
			{
				if( $args{arg1} =~ /^[0-9]+$/ ) { $kernel->post( IRC => privmsg => CHANNEL, "[BR]7 There is noone ranked in position $args{arg1} yet. Total number of ranked players is " . rankedPlayersCount() . "" ); }
				else { $kernel->post( IRC => privmsg => CHANNEL, "[BR]7 $args{arg1} is not yet ranked." ); }
			}
		}
	}
	
	else
	{
		# We are running from ingame
		if ( !$args{arg1} ) { ( $result, %hash ) = get_rank ( $args{nick}, 1 ) }
		elsif( $args{arg1} =~ /^[0-9]+$/ ) { ( $result, %hash ) = get_rankPos($args{arg1}); }
		else { ( $result, %hash ) = get_rank( $args{arg1}, 0 ); }
		
		
		# Check if name provided is not unique ( result == 2 )
		if ( $result == 2 )
		{
			my $namesFound;
			while ( my ($key, $value) = each(%hash) ) { $namesFound .= "$value, "; }
			$namesFound = substr ( $namesFound, 0, -2 );			# Trim trailing ', '
			plugin::RenRemCMD ( "msg $args{arg1} was found in more than one name. The first " . keys(%hash) . " matches are :: $namesFound" );
		}
		
		# Now check if there was a result found
		elsif ( $result == 1 )
		{
			my $rankingData;
			if ( $config{rankMode} == 1 )
			{
				$rankingData = "$hash{points} points";
			}
			elsif ( $config{rankMode} == 2 )
			{
				$rankingData = "$hash{kills} kills";
			}
			elsif ( $config{rankMode} == 3 )
			{
				$rankingData = "a k/d of " . sprintf ( "%.1f", ( $hash{kills} / $hash{deaths} ) );
			}
			plugin::RenRemCMD ( "msg $hash{name} has $rankingData and is ranked at position $hash{rank} out of " . rankedPlayersCount() . " players." );
		}
		
		# No result found
		else
		{
			if( $args{arg1} =~ /^[0-9]+$/ ) { plugin::RenRemCMD ( "msg There is noone ranked in position $args{arg1} yet. Total number of ranked players is " . rankedPlayersCount() ); }
			elsif ( $args{arg1} ) { plugin::RenRemCMD ( "msg $args{arg1} is not yet ranked." ); }
			else { plugin::RenRemCMD ( "msg $args{nick} you are not yet ranked, play a few games and then check again." ); }
		}
	}
}


# Function for !top command - Shows top x players
sub top
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	$args{arg1} = ( $args{arg1} =~ /^[0-9]+$/ ) ? $args{arg1} : 3;
	
	if( $args{nicktype} == 1 && $args{arg1} > 10 )
	{
		$kernel->post( IRC => privmsg => CHANNEL, "[BR] 7Error: Maximum allowed is 10. Showing top 10 ranks.");
		$args{arg1} = 10;
	}
	elsif ( $args{nicktype} != 1 && $args{arg1} > 3 )
	{
		plugin::RenRemCMD ( "msg [BR] Error: Maximum allowed ingame is 3. Showing top 3 ranks." );
		$args{arg1} = 3;
	}
	
	my $max = $dbh->selectrow_array ( "SELECT max(place) FROM ranks" );
	
	if ( $max == 0 )
	{
		if( $args{nicktype} == 1 ) { $kernel->post( IRC => privmsg => CHANNEL, "[BR] 7There are no players ranked yet." ); }
		else { plugin::RenRemCMD ( "msg [BR] There are no players ranked yet." ); }
	}
	else
	{
		my $field;		my $rankType;
		if ( $config{rankMode} == 1 )
		{ $field = 'score'; $rankType = 'points' }
		elsif ( $config{rankMode} == 2 )
		{ $field = 'kills'; $rankType = 'kills' }
		elsif ( $config{rankMode} == 3 )
		{ $field = '(kills/deaths)'; $rankType = 'k/d' }
		
		my $sth = $dbh->prepare( "SELECT name, place, $field FROM ranks ORDER BY place ASC LIMIT 0,$args{arg1}" );
		$sth->execute();		
		
		my @row;
		while ( @row = $sth->fetchrow_array )
		{
			if( $args{nicktype} == 1 ) { $kernel->post( IRC => privmsg => CHANNEL, "[BR]7 @row[1]. @row[0] with @row[2] $rankType." ); }
			else { plugin::RenRemCMD ( "msg @row[1]. @row[0] with @row[2] $rankType." ); }
		}
	}
}

# Function for !rankstats command - shows detailed information about the specified player
sub rankstats
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	my @row;
	my $message;
	
	# Check the parameters were given
	if( !$args{arg1} && $args{nicktype} == 1 ) { $message = "Error: Usage: !rankstats <name>"; }
	elsif ( !$args{arg1} ) { $args{arg1} = $args{nick}; }
	
	if ( $args{arg1} )
	{
		my $name = lc ( $args{arg1} );			$name =~ s/"/\'/;
		
		my $result;			my %rankdata;
		( $result, %rankdata ) = get_rank ( $name );
		
		# No matches found
		if ( $result == 0 ) { $message = "$name is not yet ranked."; }
		
		# Single unique match found
		elsif ( $result == 1 ) { $message = "Stats for $rankdata{name}, ranked $rankdata{rank} :: score: $rankdata{points}, kills: $rankdata{kills}, deaths: $rankdata{deaths}, games: $rankdata{games}, GDI: $rankdata{gdi}, NOD: $rankdata{nod}, MVP: $rankdata{mvp}"; }
		
		# Multiple matches found, none equal to $name
		elsif ( $result == 2 )
		{
			my $namesFound;
			while ( my ($key, $value) = each(%rankdata) ) { $namesFound .= "$value, "; }
			$namesFound = substr ( $namesFound, 0, -2 );			# Trim trailing ', '
			$message = "$name was found in more than one name. The first " . keys(%rankdata) . " matches are :: $namesFound";
		}
	}
	
	if ( $args{nicktype} == 1 ) { $kernel->post( IRC => privmsg => CHANNEL, "[BR] 7$message"); }
	else { plugin::RenRemCMD ( "msg [BR] $message" ); }
}

# Function for !update command - Updates the website
sub update
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	my ($fhTemplate, $fhSite, $file);
	my $status = 1;		# 1 = success, 0 = failure
	my $ftp;			my $ftpStatus = 0;
	
	# If upload via FTP is enabled open the FTP connection
	if ( $config{'enableFTP'} )
	{
		$ftp = Net::FTP->new( "$config{'ftpServer'}", Debug => 0 );
		if ( $ftp )
		{
			if ( $ftp->login( $config{'ftpUsername'},$config{'ftpPassword'} ) )
			{
				print "RANK PLUGIN :: FTP :: Login Successful\n";
				if ( !$ftp->cwd( $config{'ftpPath'} ) )
				{
					print "RANK PLUGIN :: FTP :: Path '$config{ftpPath}' does not exist!\n";
					$ftp->quit;
					print "RANK PLUGIN :: FTP :: Disconnected\n";
				}
				else { $ftpStatus = 1; }
			}
			else { print "RANK PLUGIN :: FTP :: Login Failed\n"; }
		}
	}
	
	# Check if ranks.txt output is needed
	if ( ( $config{siteOutputType} == 1 ) || ( $config{siteOutputType} == 3 ) )
	{
		if( !open($fhSite, ">$config{sitePath}ranks.txt") )
		{ logwrite("Failed to open $config{sitePath}ranks.txt"); $status = 0; }
		else
		{
			my @row;
			my $sth = &fetch_ranks(1000, 'place', 0);
			while ( @row = $sth->fetchrow_array )
			{
				print $fhSite "$row[3]\t$row[0]\t$row[1]\t$row[2]\t$row[4]\t$row[5]\t$row[6]\t$row[7]\t$row[8]\n";
			}
			close $fhSite;
		}
		if ( $ftpStatus )
		{
			if ( $ftp->put ( "$config{sitePath}ranks.txt" ) ) { print "RANK PLUGIN :: FTP :: File ranks.txt uploaded successful\n"; }
			else { print "RANK PLUGIN :: FTP :: File ranks.txt upload failed!\n"; }
		}
	}
	
	# Check if we need to process .htm files based on template.tpl files
	if ( ( $config{siteOutputType} == 2 ) || ( $config{siteOutputType} == 3 ) )
	{
		opendir( TEMPLATESDIR, './templates/' );
		$file = readdir( TEMPLATESDIR );
		while( $file && $status != 0 )
		{
			if( $file =~ /(.*)\.tpl$/ )
			{
				if ( &opensitefiles($fhTemplate, $fhSite, $1) )
				{
					&process($fhTemplate, $fhSite);
					closesitefiles($fhTemplate, $fhSite, $1);
					
					if ( $ftpStatus ) 
					{
						if ( $ftp->put ( "$config{sitePath}$1.htm" ) ) { print "RANK PLUGIN :: FTP :: File $1.htm uploaded successful\n"; }
						else { print "RANK PLUGIN :: FTP :: File $1.htm upload failed!\n"; }
					}
				}
				else { $status = 0; }
				
			}
			$file = readdir(TEMPLATESDIR);
		}
		closedir TEMPLATESDIR;
	}
	
	
	
	if ( $ftpStatus )
	{
		$ftp->quit;
		print "RANK PLUGIN :: FTP :: Disconnected\n";
	}
	
	if ( $status ) { $kernel->post( IRC => privmsg => CHANNEL, "[BR] 7Done updating website."); }
	else { $kernel->post( IRC => privmsg => CHANNEL, "[BR] 7Error while updating website."); }
}


# Function for setting a player to be ignored for ranking
sub rankIgnore
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	if ( $args{arg1} )
	{
		my $name = $args{arg1};			$name =~ s/"/\'/;
		
		if ( $ignoredPlayers{lc($name)} ) { $kernel->post( IRC => privmsg => CHANNEL, "[BR] 7$name is already on the ignore list."); }
		else
		{
			# Store the name in the database and add to the list
			$dbh->do ( "INSERT INTO ignoredPlayers ( name ) VALUES ( \"$name\" )" );
			$ignoredPlayers{lc($name)} = 1;
			
			$kernel->post( IRC => privmsg => CHANNEL, "[BR] 7$name has been added to the ignore list.");
		}
	}
	else { $kernel->post( IRC => privmsg => CHANNEL, "[BR] 7You must specify the name of the player to add to the ignore list. USAGE: !rankIgnore <playername>"); }
}


# Function for setting a player to not be ignored for ranking
sub rankAllow
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	if ( $args{arg1} )
	{
		my $name = $args{arg1};			$name =~ s/"/\'/;
		
		if ( !$ignoredPlayers{lc($name)} ) { $kernel->post( IRC => privmsg => CHANNEL, "[BR] 7$name is not on the ignore list..."); }
		else
		{
			# Store the name in the database and add to the list
			$dbh->do ( "DELETE FROM ignoredPlayers WHERE lower(name) = \"" . lc($name) . "\"" );
			delete $ignoredPlayers{lc($name)};
			
			$kernel->post( IRC => privmsg => CHANNEL, "[BR] 7$name has been removed from the ignore list.");
		}
	}
	else { $kernel->post( IRC => privmsg => CHANNEL, "[BR] 7You must specify the name of the player to remove from the ignore list. USAGE: !rankAllow <playername>"); }
}


# Merges two sets of rank stats into one
sub rankMerge
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	my $qryResult;
	
	if ( $args{nicktype} == 1 ) { $kernel->post( IRC => privmsg => CHANNEL, "[BR] 7This function is not available from IRC."); }
	else
	{
		# First check the user actually has rank data to merge
		my ( $result, %hash ) = get_rank ( $args{nick}, 1 );
		if ( $result == 0 ) { plugin::RenRemCMD ( "msg $args{nick}, you do not have any rank data to merge into another account!" ); }
		else
		{
			if ( !$args{arg1} ) { plugin::RenRemCMD ( "msg You must specify the account name you wish to merge your rank stats into." ); }
			else
			{
				my $name = lc($args{nick});				$name =~ s/"/\'/;
				my $newName = lc($args{arg1});			$newName =~ s/"/\'/;
				
				# Check if $newName has any existing ranking data
				my ( $result2, %hash2 ) = get_rank ( $newName, 1 );
				
				# If result == 0 then the new name has no rank data, do a straightforward
				# rename of the rank data's name
				if ( $result2 == 0 )
				{
					$qryResult = $dbh->do ( "UPDATE ranks SET name = \"$newName\" WHERE name = \"$name\"" );
				}
				else
				{
					my ($newKills, $newDeaths, $newScore, $newMvp, $newGames, $newGdi, $newNod);
					# They already have rankdata, now we have to go to the trouble of
					# merging it all... at least get_rank has already got the data
					# we need
					
					$newKills = ( $hash{kills} + $hash2{kills} );
					$newDeaths = ( $hash{deaths} + $hash2{deaths} );
					$newScore = ( $hash{points} + $hash2{points} );
					$newMvp = ( $hash{mvp} + $hash2{mvp} );
					$newGames = ( $hash{games} + $hash2{games} );
					$newGdi = ( $hash{gdi} + $hash2{gdi} );
					$newNod = ( $hash{nod} + $hash2{nod} );
					
					# Update new account, delete old one
					$qryResult = $dbh->do ( "UPDATE ranks SET kills = $newKills, deaths = $newDeaths, score = $newScore, games = $newGames, MVP = $newMvp, GDI = $newGdi, Nod = $newNod WHERE lower(name) = \"$newName\"" );
					$dbh->do ( "DELETE FROM ranks WHERE lower(name) = \"$name\"" );
				}
				
				if ( defined ( $qryResult ) ) { plugin::RenRemCMD ( "msg Rank data from the player $name has been merged into the data for player $newName. Position in the rankings will be updated at the start of the next map." ); }
				else { plugin::RenRemCMD ( "msg Unable to merge rank data for the players $name and $newName... " ); }
			}
		}
	}
}



# Function for deleting a players rank data
sub delRank
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	if ( $args{arg1} )
	{
		my $name = lc ( $args{arg1} );			$name =~ s/"/\'/;
		
		my $result = $dbh->do ( "DELETE FROM ranks WHERE lower(name) = \"$name\"" );
		
		if ( $result == 1 )
			{ $kernel->post( IRC => privmsg => CHANNEL, "[BR] 7All rank data for $name has been deleted, ranks will be re-ordered when the map next changes."); }
		else
			{ $kernel->post( IRC => privmsg => CHANNEL, "[BR] 7Unable to find any rank data for $name to delete."); }
	}
	else { $kernel->post( IRC => privmsg => CHANNEL, "[BR] 7You must specify the name of the player whose rank data you wish to delete USAGE: !delRank <playername>"); }
}



########### Event handlers

# Runs when BRenBot loads the plugin
sub start
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	
	# Set our current version in the globals table
	plugin::set_global ( "version_plugin_rank", $currentVersion );
	
	if ( $main::version >= 1.51 )
	{
		my ( undef, undef, $gdiPlayers, undef, $nodPlayers, undef, undef, undef, undef, undef ) = plugin::getGameStatus();
		if ( $gdiPlayers > 0 && $nodPlayers > 0 )
			{ $rankGame = 1; }
	}
	else
	{
		my %gameinfo = plugin::get_gameinfo();
		if ( $gameinfo{gdi_players} > 0 && $gameinfo{nod_players} > 0 )
			{ $rankGame = 1; }
	}
	
	#print "Starting rank plugin\n";
	if ( $config{showRankOnJoinDelay} !~ m/^\d+$/ ) { print "RANK PLUGIN :: showRankOnJoinDelay option is not set or non numerical. Defaulting to 10 seconds.\n"; $config{showRankOnJoinDelay} = 10; }
	if ( $config{siteOutputType} !~ m/^(1|2|3)$/ ) { print "RANK PLUGIN :: siteOutputType is set to an invalid value. Valid values are 1, 2 or 3. Defaulting to 1\n"; $config{siteOutputType} = 1; }
	if ( $config{rankMode} !~ m/^(1|2|3)$/ ) { print "RANK PLUGIN :: rankMode is set to an invalid value. Valid values are 1, 2 or 3. Defaulting to 1\n"; $config{rankMode} = 1; }
	if ( $config{rankingMinScore} !~ m/^\d+$/ ) { print "RANK PLUGIN :: rankingMinScore option is not set or non numerical. Defaulting to 50 points.\n"; $config{rankingMinScore} = 50; }
	
	opendir( DIR, '.' );
	my $time = &get_log_time('rankings.dat');
	
	if ( $^O eq "MSWin32" )
	{
		$dbh = DBI->connect("dbi:SQLite2:dbname=rankings.dat","","");
	}
	else	# Use alternative SQLite driver for linux
	{
		$dbh = DBI->connect("dbi:SQLite:dbname=rankings.dat","","");
	}

	if( !$time )
	{
		$dbh->do(
			"CREATE TABLE ranks
			 (name	char(128) PRIMARY KEY
			 ,kills   int
			 ,deaths  int
			 ,place   int
			 ,score   int
			 ,MVP	  int
			 ,games   int
			 ,GDI	  int
			 ,NOD	  int)");
			 
		$dbh->do(
			"CREATE TABLE temp
			 (rank1	integer PRIMARY KEY
			 ,name1	char(128)
			 ,kills1   int
			 ,deaths1  int
			 ,place1   int
			 ,score1   int 
			 ,MVP1	   int
			 ,games1   int
			 ,GDI1	   int
			 ,NOD1	   int)");
			
		$dbh->do( "CREATE TABLE globals ( name char(1024) PRIMARY KEY, value char(1024))");
		set_global ( "version", $currentVersion );
		
		$dbh -> do ( "CREATE TABLE ignoredPlayers ( name char(128) )" );
	}
	else
	{
		# Check version
		$dbVersion = get_global ( "version" );
		if ( !$dbVersion ) { $dbVersion = 1.0; }
		
		if ( $dbVersion != $currentVersion )
		{
			print "RANK PLUGIN :: Database is out of date. DB is $dbVersion, current is $currentVersion. Updating to new version...\n";
			
			# Run updates for each old version sequentially
			if ( $dbVersion < 1.1 )
			{
				print "RANK PLUGIN :: Updating db to 1.1....\n";
				print "  creating table ignoredPlayers\n";
				$dbh -> do ( "CREATE TABLE ignoredPlayers ( name char(128) )" );
				
				# Recreate the temp table
				print "  dropping extra columns in temp\n";
				$dbh -> do ( "DROP TABLE temp" );
				$dbh -> do ( "CREATE TABLE temp ( rank1	integer PRIMARY KEY, name1 char(128), kills1 int ,deaths1 int ,place1 int ,score1 int ,MVP1 int ,games1 int ,GDI1 int ,NOD1 int) ");
				
				# If only SQLite supported DROP COLUMN this would be SOOOO much easier...
				print "  dropping extra columns in ranks\n";
				$dbh -> do ( "INSERT INTO temp SELECT NULL, name, kills, deaths, place, score, MVP, games, GDI, NOD FROM ranks ORDER BY score DESC");
				$dbh -> do ( "DROP TABLE ranks" );
				$dbh -> do ( "CREATE TABLE ranks ( name char(128) PRIMARY KEY, kills int ,deaths int ,place int ,score int ,MVP int ,games int ,GDI int ,NOD int) ");
				$dbh -> do ( "INSERT INTO ranks SELECT name1, kills1, deaths1, rank1, score1, MVP1, games1, GDI1, NOD1 FROM temp");
			}
			
			# Now do update 1.1 -> 1.2
			if ( $dbVersion < 1.2 )
			{
				print "RANK PLUGIN :: Updating db to 1.2....\n";
				print "  checking for split userdata records..\n";
				
				my $sth = $dbh->prepare( "SELECT COUNT(name) AS number, name, SUM(kills), SUM(deaths), SUM(score), SUM(mvp), SUM(games), SUM(gdi), SUM(nod) FROM ranks GROUP BY LOWER(name) ORDER BY COUNT(name) DESC" );
				$sth->execute();
				
				my $counter = 0;
				my @row;
				while ( @row = $sth->fetchrow_array )
				{
					# Check if there are no more accounts to repair
					if ( $row[0] == 1 ) { last; }
					
					# If there are more than two identical names first DELETE the
					# multiple accounts
					$dbh->do ( "DELETE FROM ranks WHERE lower(name) = \"" . lc($row[1]) . "\"" );
					
					# Now create one new record with the correct totals
					$dbh->do ( "INSERT INTO ranks ( name, kills, deaths, score, mvp, games, gdi, nod, place ) VALUES ( \"$row[1]\", $row[2], $row[3], $row[4], $row[5], $row[6], $row[7], $row[8], 0 )" );
					$counter++;
				}
				
				print "  $counter sets of results have been repaired\n";
				
				# If there were fixed results, reorder all the rankings
				if ( $counter ) { calc_rank_v2() };
			}
			
			# Update the version number
			set_global ( "version", $currentVersion );
		}
	}
	
	closedir DIR;
	
	# Load ignored players list
	loadIgnoredPlayers();
}

# Runs when BRenBot shuts down
sub stop
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	
	$dbh->disconnect;
}

# Runs when a !command specified in the .xml file is typed
sub command
{
	# trigger on !commands
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	if ($args{command} eq "rank")
	{
		$kernel->yield("rank" => \%args);
	}
	elsif ($args{command} eq "top")
	{
		$kernel->yield("top" => \%args);
	}
	elsif ($args{command} eq "rankstats")
	{
		$kernel->yield("rankstats" => \%args);
	}
	elsif ($args{command} eq "update")
	{
		$kernel->yield("update" => \%args);
	}
	elsif ($args{command} eq "rankignore")
	{
		$kernel->yield("rankIgnore" => \%args);
	}
	elsif ($args{command} eq "rankallow")
	{
		$kernel->yield("rankAllow" => \%args);
	}
	elsif ($args{command} eq "rankmerge")
	{
		$kernel->yield("rankMerge" => \%args);
	}
	elsif ($args{command} eq "delrank")
	{
		$kernel->yield("delRank" => \%args);
	}
}

# Runs everytime a player joins the game
sub playerjoin
{
	# Trigger on playerjoin
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	if ( $main::version >= 1.51 )
	{
		my ( undef, undef, $gdiPlayers, undef, $nodPlayers, undef, undef, undef, undef, undef ) = plugin::getGameStatus();
		if ( $gdiPlayers > 0 && $nodPlayers > 0 )
			{ $rankGame = 1; }
	}
	else
	{
		my %gameinfo = plugin::get_gameinfo();
		if ( $gameinfo{gdi_players} > 0 && $gameinfo{nod_players} > 0 )
			{ $rankGame = 1; }
	}
	
	# Send a message to the player if enabled in the config, after the
	# specified delay
	if ( $config{showRankOnJoin} )
	{
		my $next_time = int( time() ) + $config{showRankOnJoinDelay};
		$kernel->alarm( joinmessage => $next_time => \%args );
	}
}


# Runs every time a new map loads
sub mapload
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	if ( $main::version >= 1.51 )
	{
		my ( undef, undef, $gdiPlayers, undef, $nodPlayers, undef, undef, undef, undef, undef ) = plugin::getGameStatus();
		if ( $gdiPlayers > 0 && $nodPlayers > 0 )
			{ $rankGame = 1; }
		else
			{ $rankGame = 0; }
	}
	else
	{
		my %gameinfo = plugin::get_gameinfo();
		if ( $gameinfo{gdi_players} > 0 && $gameinfo{nod_players} > 0 )
			{ $rankGame = 1; }
		else
			{ $rankGame = 0; }
	}

	my $next_time = int( time() ) + 5;
	$kernel->alarm( process_results => $next_time => \%args );
	$next_time = int( time() ) + 10;
	$kernel->alarm( update => $next_time => \%args );
}



########### Other Functions

# Function for showing a players rank when they join.
sub joinmessage 
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};

	my $result;
	my %hash;

	( $result, %hash ) = get_rank( $args{nick}, 1 );
	if ( $result != 1 ) { plugin::RenRemCMD ( "msg $args{nick} is not ranked yet." ) }
	else
	{
		if ( ($hash{rank}) <= ($config{sirenMinRank}) ) { plugin::RenRemCMD( "snda amb_airraid.wav" ); }
		my $rankingData;
		if ( $config{rankMode} == 1 )
		{
			$rankingData = "$hash{points} points";
		}
		elsif ( $config{rankMode} == 2 )
		{
			$rankingData = "$hash{kills} kills";
		}
		elsif ( $config{rankMode} == 3 )
		{
			$rankingData = "a k/d of " . sprintf ( "%.1f", ( $hash{kills} / $hash{deaths} ) );
		}
		plugin::RenRemCMD( "msg $hash{name} has $rankingData and is ranked at position $hash{rank} out of " . rankedPlayersCount() . " players." );
	}
}


# Process game results
sub process_results 
{
	my ( $session, $heap, $args ) = @_[ SESSION, HEAP, ARG0 ];
	my $kernel = $_[KERNEL];
	my %args = %{$args};
	
	my ($diff, $curlognumber, $path, $extension, $counter, $curlogtime, $logtime, $lognumber);
	
	# Get the name of the newest results file.
	my $logfile = &get_logname();
	
	if( $logfile =~ /^(.*results)(\d*)(\.txt)/ ) {
		$path		 = $1;
		$curlognumber = $2;
		$extension	= $3;		
	}

	$logtime   = get_global('LOGTIME');
	$lognumber = get_global('LOGNUMBER');
	
	# Handle any games played while brenbot was offline
	if( $lognumber ) {
		$diff = $curlognumber - $lognumber;
	}
	else {
		$diff = 1;
	}

	if( $diff == 1 ) {
		do_results($logfile);
	}
	else {
		if( $diff > 0 ) {			
			while( $lognumber < $curlognumber ) {
				$lognumber++;
				
				$logfile = "$path$lognumber$extension";
				$curlogtime = &get_log_time($logfile);
				
				if( $logtime < $curlogtime ) {
					do_results($logfile);
				}
			}			
		}
		elsif( $diff < 0 ) {
			$diff = (100 - $lognumber) + $curlognumber;
			if( $diff == 1 ) {
				do_results($logfile);
			}
			else {
				$counter = 1;
				while( $counter <= $diff ) {
					$lognumber++;
					if( $lognumber > 100 ) {
						$lognumber = 1;
					}
					
					$logfile = "$path$lognumber$extension";
					$curlogtime = &get_log_time($logfile);
					
					if( $logtime < $curlogtime ) {
						do_results($logfile);
					}	
									
					$counter++;
				}
			}
		}	
	}
	
	set_global('LOGNUMBER', $curlognumber);
	set_global('LOGTIME', time);
	&calc_rank_v2();

	plugin::RenRemCMD("msg [BR] Done calculating new ranks.");
}

sub get_log_time {
	my ($logfile) = @_;
	
	my ($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$atime,$mtime,$ctime,$blksize,$blocks) = stat($logfile);

	return($mtime);
}

# Processes resultsxx.txt files
sub do_results
{
	my $logfile = @_[0];
	
	if ( $config{DEBUG} )
	{
		open(DEBUG, ">>./DEBUG_ranks.txt");
		print DEBUG "\n\n\nOpening results file $logfile\n";
	}
	
	#$logfile = "../results53.txt";		# Debug line for using specific logfiles
	if( !open(RESULTS, $logfile) )
	{
		if ( $config{DEBUG} ) { print DEBUG "Failed to open $logfile\n"; }
		#logwrite("Failed to open resultfile $logfile.");
		return;
	}
	
	if ( !$rankGame )
		{ return; }


	# Processes results one by one
	my $line;		my $lineNumber = 0;
	while( $line = <RESULTS> )
	{
		$lineNumber++;
		if ( $config{DEBUG} ) { print DEBUG "\nReading line $lineNumber...\n $line\n"; }
		
		if( $line =~ /^\s*\d+\./ )
		{
			# Line with player results found.
			if ( $config{DEBUG} ) { print DEBUG "Line contains player data\n"; }
			
			# Check if the player was loading, if they were we ain't interested
			if ( $line !~ m/##Loading/i )
			{
				$line =~ s/##/ /;			# Get rid of the ## for players that left early
				
				# Get player data from the line
				$line =~ m/^\s*(\d+)\.\s*(.*?)\s*(\d*)\s*(\d*)\s*(\d*\.\d*|-)\s*(\S*)\s*(\S*)\s*(\S*)\s*(\S*)?\s*?(GDI|Nod|Allies|Soviet)\s*$/i;
				my ( $pos, $name, $kills, $deaths, $kd, $credits, $score, $ladder, $rank, $team ) = ( $1, $2, $3, $4, $5, $6, $7, $8, $9, $10 );
				if ( $config{DEBUG} ) { print DEBUG "Player Data: $name, $kills, $deaths, $score, $ladder, $rank, $team\n"; }
				
				my $mvp = ( $pos == 1 ) ? 1 : 0;
				
				if ( $config{DEBUG} )
				{
					# Get old rank data for debugger
					my ($result, %rankData) = get_rank($name, 1);
					if ( $result ) { print DEBUG "Rank data before update: $rankData{name}, $rankData{kills}, $rankData{deaths}, $rankData{points}, $rankData{mvp}, $rankData{games}, $rankData{gdi}, $rankData{nod}\n"; }
					else { print DEBUG "Player is not yet ranked\n"; }
				}
				
				if ( $ignoredPlayers{lc($name)} != 1 )
				{
					if ( $score >= $config{rankingMinScore} )
					{
						&dbwrite($name, $kills, $deaths, $score, $team, $mvp);
						
						if ( $config{DEBUG} )
						{
							# Get new rank data for debugger
							my ($result, %rankData) = get_rank($name, 1);
							if ( $result ) { print DEBUG "Rank data after update: $rankData{name}, $rankData{kills}, $rankData{deaths}, $rankData{points}, $rankData{mvp}, $rankData{games}, $rankData{gdi}, $rankData{nod}\n"; }
							else { print DEBUG "Player is not ranked..\n"; }
						}
					}
					elsif ( $config{DEBUG} ) { print DEBUG "Player does not have enough points to be ranked\n"; }
				}
				elsif ( $config{DEBUG} ) { print DEBUG "Player is on ignore list\n"; }
			}
			elsif ( $config{DEBUG} ) { print DEBUG "Player did not finish loading\n"; }
		}
	}
	
	if ( $config{DEBUG} )
	{
		print DEBUG "Finished reading results file $logfile\n";
		close (DEBUG);
	}
	
	close(RESULTS);
}

sub dbwrite 
{
	my ($name, $kills, $deaths, $score, $side, $mvp) = @_;
	my ($rank, $games, $gdi, $nod, $wScore, $wKills, $wDeaths);
	
	# Perhaps update sometime to use get_rank() to get the rank data?
	my @row = $dbh->selectrow_array ( "SELECT * FROM ranks WHERE lower(name) = '" . lc($name) . "'" );
	
	my ( $old_name, $old_kills, $old_deaths, $old_rank, $old_score, $old_mvp, $old_games, $old_gdi, $old_nod ) = @row;
	
	if( $old_name ) 
	{
		$kills   = $kills  + $old_kills;
		$deaths  = $deaths + $old_deaths;
		$score   = $score  + $old_score;
		$games   = ++$old_games;
		
		
		if( ( $side =~ m/Nod/i ) || ( $side =~ m/Soviet/i ) ) {
			$gdi = $old_gdi;
			$nod = ++$old_nod;
		}
		else {
			$gdi = ++$old_gdi;
			$nod = $old_nod;
		}
		
		if( $mvp == 1 ) { $mvp = ++$old_mvp; }
		else { $mvp = $old_mvp; }
		
		# Calculate new rank and update all players taken over.
		#$rank   = &calc_rank( $name, $old_rank, $score );
		$rank = 0;
		
		$dbh->do( "
			UPDATE ranks 
			SET	kills   = $kills
			,	  deaths  = $deaths
			,	  score   = $score
			,	  place   = $rank 
			,	  MVP	 = $mvp
			,	  games   = $games
			,	  GDI	 = $gdi
			,	  NOD	 = $nod
			WHERE  lower(name) = '" . lc($name) . "'" );
	}
	else {
		#$rank = &calc_rank( $name, 0, $score );
		$rank = 0;
		
		if( $mvp == 1 ) { $mvp = 1; }
		else { $mvp = 0; }
		
		if( $side =~ /Nod/ ) { $gdi = 0; $nod = 1; }
		else { $gdi = 1; $nod = 0; }
		
		$dbh->do("
			INSERT INTO ranks 
			VALUES('$name'
			,	  $kills
			,	  $deaths
			,	  $rank
			,	  $score
			,	  $mvp
			,	  1
			,	  $gdi
			,	  $nod)");	
	}
	
	return();
}


# Copies all ranks over to temp and orders them by score, then copies
# them back to ranks in the right order
sub calc_rank_v2
{
	$dbh->do( "DELETE FROM temp" );
	
	if ( $config{rankMode} == 1 )
	{ $dbh->do( "INSERT INTO temp SELECT NULL, * FROM ranks ORDER BY score desc" ); }
	elsif ( $config{rankMode} == 2 )
	{ $dbh->do( "INSERT INTO temp SELECT NULL, * FROM ranks ORDER BY kills desc" ); }
	elsif ( $config{rankMode} == 3 )
	{ $dbh->do( "INSERT INTO temp SELECT NULL, * FROM ranks ORDER BY (kills/deaths) desc" ); }
	
	$dbh->do( "DELETE FROM ranks" );
	
	$dbh->do( "INSERT INTO ranks
		select a.name1
		,	  a.kills1
		,	  a.deaths1
		,	  a.rank1
		,	  a.score1
		,	  a.MVP1
		,	  a.games1
		,	  a.GDI1  
		,	  a.NOD1  
		from   temp a" );
}


# Redundant
sub calc_rank
{
	my ($name, $old_rank, $new_score) = @_;
	my $new_rank  = 0;
	my @row;
	my $query;

	if( $old_rank != 0 ) {
		$query = "SELECT * FROM ranks WHERE place < ? AND score < ? ORDER BY place ASC";
		my $sth = $dbh->prepare($query);
		
		$sth->execute( $old_rank, $new_score );
		
		if( @row = $sth->fetchrow_array ) {
			$new_rank = @row[3];
			
			$dbh->do("UPDATE ranks SET place = ( @row[3] + 1 ) WHERE name = '@row[0]'");
			
			while( @row = $sth->fetchrow_array ) {
				$dbh->do("UPDATE ranks SET place = ( @row[3] + 1 ) WHERE name = '@row[0]'");
			}			
		}
		else {
			$new_rank = $old_rank;
		}
		
		$sth->finish;
	}
	else {
		$query = "SELECT * FROM ranks WHERE score < ? ORDER BY place ASC";
				
		my $sth = $dbh->prepare($query);
		
		$sth->execute( $new_score );		

		if( @row = $sth->fetchrow_array ) {
			$new_rank = @row[3];
			
			$dbh->do("UPDATE ranks SET place = ( @row[3] + 1 ) WHERE name = '@row[0]'");
			
			while( @row = $sth->fetchrow_array ) {
				$dbh->do("UPDATE ranks SET place = ( @row[3] + 1 ) WHERE name = '@row[0]'");
			}					
		}
		else {
			$query = "SELECT max(place) FROM ranks";
			my $sta = $dbh->prepare($query);
			
			$sta->execute();
			
			if( @row = $sta->fetchrow_array ) {
				if( @row[0] ) {
					$new_rank = @row[0] + 1;
				}
				else {
					$new_rank = 1;
				}
			}
			
			$sta->finish;
			
		}
		
		$sth->finish;
	}
	return $new_rank;
}




# Gets rank data for the specified name. Returns 0 on fail, 1 on success, 
# 2 on non-unique names
sub get_rank
{
	my ( $name, $matchUniqueOnly ) = @_[ 0, 1 ];
	my ( @row, @row2 );
	
	# Convert name to lowercase, and strip out any "
	$name = lc( $name );			$name =~ s/"/\'/g;
	
	my $whereString = ( $matchUniqueOnly ) ? "= \"$name\"" : "LIKE \"%$name%\"";
	my $sth = $dbh->prepare( "SELECT * FROM ranks WHERE lower(name) $whereString" );
	$sth->execute();
	
	
	# Get first row of the result - if none return 0 (failure)
	if ( !(@row = $sth->fetchrow_array) ) { return 0; }
	else
	{
		# We have a row of playerdata, now check there are no more rows
		# If there are get a list of up to 5 names, and return 2 (non unique)
		#
		# 1.2 -> Also check the name is not an exact match, if it is we want to
		# return that one anyway, so don't bother looking for more records
		if ( ( ( $matchUniqueOnly != 1 ) && ( @row2 = $sth->fetchrow_array ) ) && ( $name ne lc ( $row[0] ) ) )
		{
			my %returnHash;
			
			if ( $name eq lc ( $row2[0] ) )
			{
				# Name is exact match, return it along with a hash of rank data
				%returnHash = ( 'rank' => $row2[3], 'name' => $row2[0], 'points' => $row2[4], 'kills' => $row2[1], 'deaths' => $row2[2], 'mvp' => $row2[5], 'games' => $row2[6], 'gdi' => $row2[7], 'nod' => $row2[8] );
				return ( 1, %returnHash );
			}
			
			
			#Otherwise start the return hash
			%returnHash = ( 'name1' => $row[0], 'name2' => $row2[0] );
			
			# Continue looping through the results
			my $counter = 2;
			while ( @row2 = $sth->fetchrow_array )
			{
				# Check for an exact match, if it is an exact match return this
				# instead of a list of names, as thats the one we want anyway
				if ( $name eq lc ( $row2[0] ) )
				{
					# Name is exact match, return it along with a hash of rank data
					%returnHash = ( 'rank' => $row2[3], 'name' => $row2[0], 'points' => $row2[4], 'kills' => $row2[1], 'deaths' => $row2[2], 'mvp' => $row2[5], 'games' => $row2[6], 'gdi' => $row2[7], 'nod' => $row2[8] );
					return ( 1, %returnHash );
				}
				
				# Only add more names to the list if the counter is 5 or less
				$counter++;
				if ( $counter <= 5 ) { $returnHash{"name$counter"} = $row2[0]; }
			}
			
			# If we didn't find an exact match anywhere return the first 5 names
			return ( 2, %returnHash );
		}
		else
		{
			# Name is unique, return it along with a hash of rank data
			my %returnHash = ( 'rank' => $row[3], 'name' => $row[0], 'points' => $row[4], 'kills' => $row[1], 'deaths' => $row[2], 'mvp' => $row[5], 'games' => $row[6], 'gdi' => $row[7], 'nod' => $row[8] );
			return ( 1, %returnHash );
		}
	}
}




# Returns a hash with the rank data for the specified position
# Returns 0 on fail, 1 on success
sub get_rankPos
{
	my $position = @_[0];
	my @row;

	my $sth = $dbh->prepare( "SELECT * FROM ranks WHERE place = $position" );
	$sth->execute();
	
	# Get the result row, if none is present return 0 (failure)
	if ( !(@row = $sth->fetchrow_array) ) { return 0; }
	else
	{
		# We have data, so return 1 (success) and a hash of the rank data
		my %returnHash = ( 'rank' => $row[3], 'name' => $row[0], 'points' => $row[4], 'kills' => $row[1], 'deaths' => $row[2], 'mvp' => $row[5], 'games' => $row[6], 'gdi' => $row[7], 'nod' => $row[8] );
		return ( 1, %returnHash );
	}
}




# Function for getting the total number of ranked players
sub rankedPlayersCount
{
	return $dbh->selectrow_array ( "SELECT max(place) FROM ranks" );
}



sub get_logname
{
	my ($line, $filename, $file, $time, $latest, $smallesttime);
	my @path;
	
	if(open(CONFIG, 'brenbot.cfg')) {
		while ($line = <CONFIG>) {
			if( $line =~ /^\s*fdslogfilepath/i ) {
				@path = split(/=/,$line);
			}
		}
	}
	else {
		return();
	}

	my $path = @path[1];
	$path =~ s/\s+//;
	$path =~ s/\s+//;
	opendir( LOGDIR, $path );
	while( $file = readdir(LOGDIR) ) {
		$filename = "$path$file";
		$time = &get_log_time($filename);
		if( $file =~ /results/ ) {
			if( !$smallesttime || $smallesttime < $time ) {
				$latest	   = $filename;
				$smallesttime = $time;
			}
		}
	}
	closedir LOGDIR;
	
	return $latest;
}
	
sub logwrite
{
	my ($line) = @_;
	
	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
	$mon++;
	$year = $year + 1900;
	
	open(LOG, ">>rankings.log");
		
	print LOG "[$mday-$mon-$year $hour:$min] $line\n";
	
	close(LOG);
}


sub opensitefiles
{
	my $filename = @_[2];
	my ($fhTemplate, $fhSite);
	
	if( !open($fhTemplate, "./templates/$filename.tpl") )
	{
		logwrite("Failed to open ./templates/$filename.tpl");
		return 0;
	}

	logwrite("Writing to $config{sitePath}$filename.htm");
	if( !open($fhSite, ">$config{sitePath}$filename.htm") )
	{
		close( $fhTemplate );
		logwrite("Failed to open $config{sitePath}$filename.htm");
		return 0;
	}
	else
	{
		@_[0] = $fhTemplate;
		@_[1] = $fhSite;
		return 1;
	}
}

sub closesitefiles
{
	my ($fhTemplate, $fhSite, $filename) = @_;

	if( !close($fhTemplate) ) { logwrite("Failed to close $filename.tpl"); }
	if( !close($fhSite) ) { logwrite("Failed to close $filename.htm"); }
}

sub process
{
	my ($fhTemplate, $fhSite) = @_;
	my ($line, $inloop, $sth, $looptext, $totalrows, $sort, $start);
	
	$inloop = 0;

	while( $line = <$fhTemplate> )
	{
		if( $line =~ /\/CDS-LOOP-TOTAL-PLAYERS/ )
		{
			&print_loop($looptext, $totalrows, $sort, $start, $fhSite);
		
			$inloop = 0;
		}
		elsif( $line =~ /CDS-LOOP-TOTAL-PLAYERS/ )
		{
			$inloop = 1;
			
			$totalrows = ( $line =~ /top\s*=\s*"?(\d*)"?/i ) ? $1 : 1000;
			$sort = ( $line =~ /sortby\s*=\s*"?(.*)"?/i ) ? $1: "place";
			$start = ( $line =~ /start\s*=\s*"?(\d*)"?/i ) ? $1 : 0;
		}
		else
		{
			if( $inloop == 0 ) { print $fhSite "$line";	}
			else { $looptext = "$looptext $line"; }
		}
	}
	
	return 1;
}

sub print_loop
{
	my ($looptext, $totalrows, $sort, $start, $fhSite) = @_;
	my ($temptext, $count);
	my @row;
	
	my $sth = &fetch_ranks($totalrows, $sort, $start);
	
	my $counter  = 0;
	my $stop	 = 0;
	while( $counter < $totalrows && $stop == 0 )
	{
		$temptext = $looptext;
		

		if( @row = $sth->fetchrow_array )
		{
			$count = $counter + 1;
			&replace($temptext, $count, @row);
			
			print $fhSite "$temptext";
		}
		else
		{
			$stop = 1;
		}
		
		$counter++;
	}
	
	return 0;
}

sub fetch_ranks
{
	my ($totalrows, $sort, $start) = @_;
	my ($sth);

	if( $start != 0 ) {
		$sth = $dbh->prepare(
			"SELECT *
			 FROM   ranks
			 WHERE  $sort >= $start
			 ORDER BY $sort"
		);
	}
	else {
		$sth = $dbh->prepare(
			"SELECT *
			 FROM   ranks
			 ORDER BY $sort"
		);
	}
		
	$sth->execute();
			
	return($sth);
}

sub replace
{
	my ($text, $count, @row) = @_;
	my ($kills, $deaths, $kd, $rounded);
	
	my $name = &html_escape_replace(@row[0]);
	$text =~ s/\$CDS-PLAYER-DISPLAYNAME\$/$name/;
	$text =~ s/\$CDS-PLAYER-KILLS\$/@row[1]/;
	$text =~ s/\$CDS-PLAYER-DEATHS\$/@row[2]/;
	$text =~ s/\$CDS-PLAYER-RANK\$/@row[3]/;

	if( @row[1] == 0 ) {
		$kd = 0;		
	}
	else {
		$kills = @row[1];

		if( @row[2] == 0 ) {
			$deaths = 1;
		}
		else {
			$deaths = @row[2];
		}

		$kd = $kills/$deaths;
		$kd = round($kd);
	}

	$text =~ s/\$CDS-PLAYER-KILLDEATH\$/$kd/;
	$text =~ s/\$CDS-PLAYER-SCORE\$/@row[4]/;
	$text =~ s/\$CDS-PLAYER-MVP\$/@row[5]/;
	$text =~ s/\$CDS-PLAYER-GAMES\$/@row[6]/;
	$text =~ s/\$CDS-PLAYER-GDI\$/@row[7]/;
	$text =~ s/\$CDS-PLAYER-NOD\$/@row[8]/;
	$rounded = round(@row[4]/@row[6]);
	$text =~ s/\$CDS-PLAYER-WSCORE\$/$rounded/;
	$rounded = round(@row[1]/@row[6]);
	$text =~ s/\$CDS-PLAYER-WKILLS\$/$rounded/;
	$rounded = round(@row[2]/@row[6]);
	$text =~ s/\$CDS-PLAYER-WDEATHS\$/$rounded/;
	$text =~ s/\$COUNT\$/$count/;

	@_[0] = $text;
}

sub html_escape_replace {
	my ($name) = @_[0]; 

	$name =~ s/</&lt\;/;
	$name =~ s/>/&gt\;/;

	return $name;
}

sub round {
	my ($number) = @_[0];
	my ($rounded);

	$rounded = sprintf("%.1f", $number);

	return $rounded;
	
#	return int($number + .5 * ($number <=> 0));
}


# Function for getting a global value
sub get_global {
	my ($name) = @_;
	
	my ($value) = $dbh->selectrow_array (
				"SELECT value
				 FROM   globals
				 WHERE  name  = '$name'");
				 
	return($value);
}


# Function for setting a global value
sub set_global {
	my ($name, $value) = @_;
	
	my ($excists) = $dbh->selectrow_array (
				"SELECT count(*)
				 FROM   globals
				 WHERE  name  = '$name'");
	
	if( $excists == 1 ) {
		$dbh->do (
		   "UPDATE globals
			SET	value = '$value'
			WHERE  name  = '$name'");	
	}
	else {
		$dbh->do (
		   "INSERT INTO globals
			VALUES( '$name', '$value')");	
	}

}


# Function of loading the list of ignored players when the plugin loads
sub loadIgnoredPlayers
{
	my $query;
	my @row;
	$query = $dbh->prepare ( "SELECT name FROM ignoredPlayers" );
	$query->execute();
	
	while ( @row = $query->fetchrow_array )
	{
		# ALWAYS use lower case when dealing with ignored players, to prevent
		# muckups with capitals
		$ignoredPlayers{lc($row[0])} = 1;
	}
}

1;